<script>
    import PageLayout from "$lib/layouts/PageLayout.svelte";
  </script>
  
  <PageLayout title="Upcoming" showBack={true}>
    <!-- Your cards or list will go here -->
    <h3>content area here...</h3>
  </PageLayout>
  