<script>
    import PageHeader from "$lib/components/PageHeader.svelte";
    import AssignVolunteer from "$lib/components/AssignVolunteer.svelte";
    import homeIcon from "$lib/assets/home.svg";
  
    let shortlist = [
      {
        id: 1,
        category: "Household Support",
        requestId: "124",
        iconSrc: homeIcon,
        name: "Michael Lee",
        photoSrc: "",
        time: "6:30 PM",
        date: "11 Nov 2025",
        note: "I need help cleaning my home after returning from the hospital. Preferably sometime this weekend. I need help cleaning my home after returning from the hospital. Preferably sometime this weekend.",
        createdOn: "02 Nov 2025"
      },
      {
        id: 2,
        category: "Household Support",
        requestId: "125",
        iconSrc: homeIcon,
        name: "Sarah Kim",
        photoSrc: "",
        time: "2:00 PM",
        date: "12 Nov 2025",
        note: "I need help cleaning my home after returning from the hospital. Preferably sometime this weekend. I need help cleaning my home after returning from the hospital. Preferably sometime this weekend.",
        createdOn: "03 Nov 2025"
      },
      {
        id: 3,
        category: "Household Support",
        requestId: "126",
        iconSrc: homeIcon,
        name: "David Chen",
        photoSrc: "",
        time: "10:00 AM",
        date: "13 Nov 2025",
        note: "I need help cleaning my home after returning from the hospital. Preferably sometime this weekend. I need help cleaning my home after returning from the hospital. Preferably sometime this weekend.",
        createdOn: "04 Nov 2025"
      }
    ];
  
    let showAssignCard = false;
    const openAssignCard = () => (showAssignCard = true);
    const closeAssignCard = () => (showAssignCard = false);
  </script>
  
  <PageHeader title="My Shortlist" showBack={true} />
  
  <div class="container">
    {#each shortlist as card}
      <div class="card">
        <!-- Header -->
        <div class="header-box">
          <img src={card.iconSrc} alt="icon" class="header-icon" />
          <div class="header-text">
            <p class="title">{card.category}</p>
            <p class="subtitle faded">Request ID: {card.requestId}</p>
          </div>
        </div>
  
        <!-- Profile Section -->
        <div class="profile-section">
          {#if card.photoSrc}
            <img src={card.photoSrc} alt={card.name} class="photo" />
          {:else}
            <div class="photo placeholder"></div>
          {/if}
          <p class="name">{card.name}</p>
        </div>
  
        <!-- Time & Date (stacked, left aligned) -->
        <div class="datetime-stack">
          <p class="bold">{card.time}</p>
          <p class="faded">{card.date}</p>
        </div>
  
        <!-- Note -->
        <div class="note-box">
          <h5>Note:</h5>
          <p class="note-text">{card.note}</p>
        </div>
  
        <!-- Created On -->
        <p class="created-on">Created on {card.createdOn}</p>
  
        <!-- Buttons -->
        <div class="button-row">
          <button class="assign-btn" on:click={openAssignCard}>Assign CV</button>
          <button class="export-btn">Export</button>
        </div>
      </div>
    {/each}
  </div>
  
  <!-- Assign Volunteer Overlay -->
  {#if showAssignCard}
    <div class="assign-overlay">
      <AssignVolunteer {closeAssignCard} />
    </div>
  {/if}
  
  <style>
  .container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: space-around;
    padding: 20px;
    background: #FDFAF3
  }
  
  .card {
    width: 300px;
    background: #fff;
    padding: 16px;
    border-radius: 16px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    gap: 12px;
    font-family: 'Poppins', sans-serif;
    font-size: 14px;
  }
  
  .header-box {
    display: flex;
    align-items: center;
    background: #FDFAF3;
    padding: 10px;
    border-radius: 12px;
    gap: 12px;
  }
  .header-icon { width: 32px; height: 32px; }
  .header-text .title { font-weight: 600; margin: 0; }
  .header-text .subtitle { margin: 0; color: #888; }
  
  .profile-section {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
  }
  .photo { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; }
  .photo.placeholder { background: #ccc; }
  .name { font-weight: 600; margin: 0; color: #555; }
  
  /* Time & Date stacked and left-aligned */
  .datetime-stack {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin-top: -4px;
    line-height: 1.2;
  }
  .datetime-stack p {
    margin: 0;
  }
  .datetime-stack .bold {
    font-weight: 600;
  }
  .datetime-stack .faded {
    color: #555;
    font-size: 13px;
  }
  
  .note-box h5 { margin: 0 0 4px 0; font-weight: 600; }
  .note-text { margin: 0; color: #888; }
  
  .created-on { text-align: center; color: #555; font-size: 14px; }
  
  .button-row {
    display: flex;
    gap: 8px;
  }
  .button-row button {
    flex: 1;
    padding: 8px 0;
    font-size: 14px;
    border-radius: 8px;
    cursor: pointer;
  }
  .assign-btn { background: #E59000; color: white; border: none; }
  .export-btn { background: white; border: 2px solid #E59000; color: #E59000; }
  
  .assign-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
  }
  
  @media(max-width: 650px){
    .container { flex-direction: column; align-items: center; }
    .button-row { flex-direction: column; }
  }
  </style>
  