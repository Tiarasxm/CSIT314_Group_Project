<script>
    import { goto } from '$app/navigation'; // SvelteKit navigation
	import googleIcon from '$lib/assets/google-logo.png?url';

	let firstName = '';
	let lastName = '';
	let email = '';
	let password = '';
	let confirmPassword = '';
	let showPassword = false;
	let showConfirmPassword = false;

	function handleSignUp() {
		console.log({ firstName, lastName, email, password, confirmPassword });
	}

    function continueWithGoogle() {
		goto('/sign-up-google');
	}
</script>

<style>
	/* Layout */
	.container {
		display: flex;
		height: 100vh;
		width: 100vw;
	}

	/* Left side */
	.left-side {
		flex: 1;
		background-color: #f5f5dc;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	/* Card */
	.card {
		background-color: white;
		border-radius: 12px;
		padding: 30px;
		width: 300px;
		box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
		display: flex;
		flex-direction: column;
		align-items: stretch;
	}

	.card h2 {
		font-size: 24px;
		font-weight: bold;
		margin-bottom: 20px;
	}

	/* Form elements */
	label {
		margin-bottom: 5px;
		font-weight: 500;
		text-align: left;
	}

	input {
		width: 100%;
		padding: 10px;
		margin-bottom: 15px;
		border-radius: 6px;
		border: 1px solid #ccc;
		outline: none;
		box-sizing: border-box;
	}

	/*First + Last Name row */
	.name-row {
		display: flex;
		gap: 10px;
		width: 100%;
		margin-bottom: 0;
	}

	.field {
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.field label {
		margin-bottom: 5px;
		font-weight: 500;
		text-align: left;
	}

	.field input {
		width: 100%;
		padding: 10px;
		border-radius: 6px;
		border: 1px solid #ccc;
		outline: none;
		box-sizing: border-box;
	}

	/* Password field with toggle */
	.password-wrapper {
		position: relative;
		width: 100%;
	}

	.password-wrapper input {
		margin-bottom: 10px;
	}

	.toggle-btn {
		position: absolute;
		right: 10px;
		top: 50%;
		transform: translateY(-50%);
		background: none;
		border: none;
		cursor: pointer;
		font-size: 1rem;
	}

	/* Buttons */
	.signup-btn {
		width: 100%;
		padding: 10px;
		background-color: #ffa500;
		color: white;
		font-weight: bold;
		border-radius: 6px;
		border: none;
		cursor: pointer;
		margin-top: 10px;
	}

	.google-btn {
		width: 100%;
		padding: 10px;
		background-color: white;
		color: #555;
		border: 1px solid #ccc;
		border-radius: 6px;
		font-weight: bold;
		cursor: pointer;
		display: flex;
		align-items: center;
		justify-content: center;
		margin: 15px 0;
	}

	.google-btn img {
		width: 18px;
		height: 18px;
		margin-right: 10px;
	}

	.portal-btn {
		width: 100%;
		padding: 10px;
		background-color: white;
		color: #ffa500;
		border: 1px solid #ffa500;
		font-weight: bold;
		border-radius: 6px;
		cursor: pointer;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 5px;
	}

	/* Text + links */
	.small-text {
		text-align: center;
		font-size: 12px;
		color: #888;
		margin-top: 10px;
	}

	.small-text a {
		font-weight: bold;
		color: #ed9121;
		text-decoration: none;
	}

	/* Divider */
	.divider {
		display: flex;
		align-items: center;
		text-align: center;
		margin: 15px 0;
		color: #bbb;
		font-size: 12px;
	}

	.divider hr {
		flex: 1;
		border: none;
		border-top: 1px solid #bbb;
	}

	.divider span {
		padding: 0 10px;
	}

	/* Right side */
	.right-side {
		flex: 1;
		background-color: #ffa500;
	}
</style>

<!-- Layout -->
<div class="container">
	<!-- Left beige side -->
	<div class="left-side">
		<div class="card">
			<h2>Sign Up</h2>

			<!-- First + Last Name Row -->
			<div class="name-row">
				<div class="field">
					<label for="firstName">First Name</label>
					<input
						id="firstName"
						type="text"
						placeholder="First name"
						bind:value={firstName}
					/>
				</div>
				<div class="field">
					<label for="lastName">Last Name</label>
					<input
						id="lastName"
						type="text"
						placeholder="Last name"
						bind:value={lastName}
					/>
				</div>
			</div>

			<!-- Email -->
			<label for="email">Email</label>
			<input
				id="email"
				type="email"
				placeholder="Enter your email"
				bind:value={email}
			/>

			<!-- Create Password -->
			<label for="password">Create Password</label>
			<div class="password-wrapper">
				<input
					id="password"
					type={showPassword ? 'text' : 'password'}
					placeholder="Enter your password"
					bind:value={password}
				/>
			</div>

			<!-- Confirm Password -->
			<label for="confirmPassword">Confirm Password</label>
			<div class="password-wrapper">
				<input
					id="confirmPassword"
					type={showConfirmPassword ? 'text' : 'password'}
					placeholder="Re-enter your password"
					bind:value={confirmPassword}
				/>

			</div>

			<!-- Sign Up Button -->
			<button class="signup-btn" on:click={handleSignUp}>Sign Up</button>

			<!-- Sign-up prompt -->
			<div class="small-text">
				Already have an account? <a href="/slog-in">Log in</a>
			</div>

			<!-- Divider -->
			<div class="divider">
				<hr />
				<span>or</span>
				<hr />
			</div>

			<!-- Google Button -->
            <button class="google-btn" on:click={continueWithGoogle}>
                <img src={googleIcon} alt="Google" />
                Continue with Google
            </button>

			<!-- Portal Prompt -->
			<div class="small-text">Are you an admin or manager?</div>

			<button class="portal-btn">
				Go to Staff Portal <span>→</span>
			</button>
		</div>
	</div>

	<!-- Right orange side -->
	<div class="right-side"></div>
</div>
