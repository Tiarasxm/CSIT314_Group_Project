<script>
    let cards = [
      { title: "Pending Request 1", text: "Details about this request", img: "https://dummyimage.com/600x400" },
      { title: "Pending Request 2", text: "Another pending request", img: "https://dummyimage.com/600x400" },
      { title: "Pending Request 3", text: "More pending info", img: "https://dummyimage.com/600x400" }
    ];
  </script>
  
  <div class="card-deck">
    {#each cards as card}
      <div class="card">
        <!-- ✅ Clean alt text (no “image” or “picture of”) -->
        <img class="card-img-top" src={card.img} alt={card.title} />
        <div class="card-body">
          <h5 class="card-title">{card.title}</h5>
          <p class="card-text">{card.text}</p>
          <p class="card-text"><small class="text-muted">Last updated just now</small></p>
        </div>
      </div>
    {/each}
  </div>
  