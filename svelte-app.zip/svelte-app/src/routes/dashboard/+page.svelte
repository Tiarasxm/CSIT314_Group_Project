<script>
  import Sidebar from '$lib/components/Sidebar.svelte';
  import { goto } from '$app/navigation';
  import UpcomingContent from '$lib/components/Upcoming.svelte';

  let pendingRequests = 3;
  let pastRequests = 5;
  let userName = "Alex";

  const goToPending = () => goto('/pending');
  const goToPast = () => goto('/past-request');
  const goToUpcoming = () => goto('/upcoming');
  const goToNewRequest = () => goto('/new-request'); // ← new function
</script>

<style>
  html, body {
    height: 100%;
    margin: 0;
    overflow: hidden;
  }

  .container {
    display: flex;
    height: 100vh;
    gap: 20px;
    padding: 20px;
    background-color: #f0f2f5;
    box-sizing: border-box;
  }

  .sidebar-wrapper {
    flex: 0 0 220px;
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  .main {
    flex: 3;
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .top-row {
    display: flex;
    gap: 20px;
    flex: 0 0 auto;
  }

  .greeting-card {
    flex: 2;
    border-radius: 15px;
    padding: 25px;
    background: linear-gradient(135deg, #ff8a00, #ffc766);
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 15px;
    font-family: sans-serif;
  }

  .greeting-card h4 {
    font-size: 1.3em;
    font-weight: 500;
    margin: 0;
  }

  .greeting-card p {
    margin: 0;
    line-height: 1.5;
  }

  .submit-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background-color: white;
    color: orange;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
    font-size: 1em;
    width: fit-content;
  }

  .submit-btn svg {
    width: 16px;
    height: 16px;
    fill: orange;
  }

  .right-column {
    display: flex;
    flex-direction: column;
    gap: 20px;
    flex: 1;
  }

  .card-box {
    background-color: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    font-family: sans-serif;
  }

  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 600;
    font-size: 1.1em;
  }

  .counter {
    color: #888;
    font-weight: 600;
  }

  .footer {
    display: flex;
    justify-content: flex-end;
  }

  .footer a, .card-header a.view-more {
    color: orange;
    text-decoration: none;
    font-weight: 500;
    font-size: 0.9em;
  }

  .footer a:hover, .card-header a.view-more:hover {
    text-decoration: underline;
    cursor: pointer;
  }

  .upcoming-box {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    background-color: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  }

  .upcoming-content {
    flex: 1;
    margin-top: 10px;
  }

  @media (max-width: 768px) {
    .container {
      flex-direction: column;
    }
    .top-row {
      flex-direction: column;
    }
    .sidebar-wrapper {
      width: 100%;
      height: auto;
    }
    .upcoming-box {
      height: auto;
    }
  }
</style>

<div class="container">
  <div class="sidebar-wrapper">
    <Sidebar />
  </div>

  <div class="main">
    <div class="top-row">
      <div class="greeting-card">
        <h4>Hi, {userName}! Need help today?</h4>
        <p>Let us know what you need. Our team and volunteers are here to help you every step of the way.</p>
        <button class="submit-btn" on:click={goToNewRequest}>
          <svg viewBox="0 0 24 24">
            <path d="M2 21l21-9L2 3v7l15 2-15 2v7z"/>
          </svg>
          Submit New Request
        </button>
      </div>

      <div class="right-column">
        <div class="card-box">
          <div class="card-header">
            <span>Pending Requests</span>
            <span class="counter">({pendingRequests})</span>
          </div>
          <div class="footer">
            <a on:click={goToPending}>View more &gt;</a>
          </div>
        </div>

        <div class="card-box">
          <div class="card-header">
            <span>Past Requests</span>
            <span class="counter">({pastRequests})</span>
          </div>
          <div class="footer">
            <a on:click={goToPast}>View more &gt;</a>
          </div>
        </div>
      </div>
    </div>

    <div class="upcoming-box">
      <div class="card-header">
        <span>Upcoming</span>
        <a class="view-more" on:click={goToUpcoming}>View more &gt;</a>
      </div>
      <div class="upcoming-content">
        <UpcomingContent />
      </div>
    </div>
  </div>
</div>
