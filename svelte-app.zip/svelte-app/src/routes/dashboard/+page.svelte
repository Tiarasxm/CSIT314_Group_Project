<script>
   let pendingRequests = 3;
   let pastRequests = 5;
   let userName = "Alex"; // example name
 </script>
 
 <style>
   body {
       margin: 0;
       font-family: sans-serif;
       background-color: #f0f0f0;
   }
 
   .container {
       display: flex;
       min-height: 100vh;
       padding: 50px;
       gap: 20px;
       box-sizing: border-box;
   }
 
   .sidebar {
       width: 220px;
       background-color: aquamarine;
       border-radius: 15px;
       padding: 20px;
       display: flex;
       flex-direction: column;
   }
 
   .main {
       flex: 1;
       display: flex;
       flex-direction: column;
       gap: 20px;
   }
 
   .top-row {
       display: flex;
       gap: 20px;
       flex: 0 0 250px; /* taller top row */
   }
 
   /* Box 2: orange gradient */
   .box-2 {
       flex: 2;
       border-radius: 15px;
       padding: 25px;
       background: linear-gradient(135deg, #ff8a00, #e52e71);
       color: white;
       display: flex;
       flex-direction: column;
       justify-content: center;
       gap: 15px;
   }
 
   .box-2 h4 {
       margin: 0;
   }
 
   .box-2 p {
       margin: 0;
       line-height: 1.5;
   }
 
   .submit-btn {
       display: inline-flex;
       align-items: center;
       gap: 8px;
       background-color: white;
       color: orange;
       border: none;
       padding: 10px 20px;
       border-radius: 8px;
       font-weight: bold;
       cursor: pointer;
       font-size: 1em;
       width: fit-content;
   }
 
   .submit-btn svg {
       width: 16px;
       height: 16px;
       fill: orange;
   }
 
   .right-column {
       display: flex;
       flex-direction: column;
       gap: 20px;
       flex: 1;
   }
 
   .box-3, .box-4 {
       display: flex;
       flex-direction: column;
       justify-content: space-between;
       padding: 20px;
       border-radius: 15px;
       background-color: aquamarine;
       box-sizing: border-box;
   }
 
   .box-3-header, .box-4-header {
       display: flex;
       justify-content: space-between;
       align-items: center;
       font-weight: bold;
       font-size: 1.2em;
   }
 
   /* Counter as faded grey parentheses */
   .box-3-counter, .box-4-counter {
       color: #888;
       font-weight: bold;
       font-size: 1em;
   }
 
   .box-3-footer, .box-4-footer {
       text-align: right;
   }
 
   .box-3-footer a, .box-4-footer a {
       color: orange;
       text-decoration: none;
       font-weight: bold;
   }
 
   .box-3-footer a:hover, .box-4-footer a:hover {
       text-decoration: underline;
       cursor: pointer;
   }
 
   .box-5 {
       background-color: aquamarine;
       border-radius: 15px;
       padding: 20px;
       flex: 1;
       display: flex;
       align-items: center;
       justify-content: center;
       font-weight: bold;
   }
 
   @media (max-width: 768px) {
       .container {
           flex-direction: column;
           padding: 20px;
       }
 
       .top-row {
           flex-direction: column;
           flex: unset;
       }
 
       .sidebar, .box-2, .box-5 {
           width: 100%;
       }
   }
 </style>
 
 <div class="container">
   <div class="sidebar">Sidebar (Box 1)</div>
 
   <div class="main">
     <div class="top-row">
       <div class="box-2">
         <h4>Hi, {userName}! Need help today?</h4>
         <p>Let us know what you need. Our team and volunteers are here to help you every step of the way.</p>
         <button class="submit-btn">
           <!-- Simple submit icon (paper plane) -->
           <svg viewBox="0 0 24 24">
             <path d="M2 21l21-9L2 3v7l15 2-15 2v7z"/>
           </svg>
           Submit New Request
         </button>
       </div>
 
       <div class="right-column">
         <div class="box-3">
           <div class="box-3-header">
             <span>Pending Requests</span>
             <div class="box-3-counter">({pendingRequests})</div>
           </div>
           <div class="box-3-footer">
             <a href="submit-new-request.html">View more &gt;</a>
           </div>
         </div>
 
         <div class="box-4">
           <div class="box-4-header">
             <span>Past Requests</span>
             <div class="box-4-counter">({pastRequests})</div>
           </div>
           <div class="box-4-footer">
             <a href="submit-new-request.html">View more &gt;</a>
           </div>
         </div>
       </div>
     </div>
 
     <div class="box-5">Box 5</div>
   </div>
 </div>
 