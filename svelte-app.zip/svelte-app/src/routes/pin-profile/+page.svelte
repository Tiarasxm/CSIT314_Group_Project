<script>
    // import pencilIcon from '$lib/assets/pencil-icon.png?url'; // 🆕 Add your pencil image here
  </script>
  
  <style>
    .container {
      display: flex;
      height: 100vh;
      width: 100vw;
      gap: 20px;
      padding: 20px;
      box-sizing: border-box;
      background-color: #f0f2f5;
    }
  
    /* Sidebar */
    .sidebar {
      flex: 1;
      background-color: white;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
  
    /* Main profile area */
    .main-form {
      flex: 3;
      background-color: white;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
      gap: 20px;
      box-sizing: border-box;

    }
  
    h2 {
      font-size: 24px;
      margin-bottom: 10px;
    }
  
    /* Inner container wrapper */
    .form-grid {
      display: flex;
      gap: 20px;
      flex: 1;
    }
  
    /* Each inner box */
    .inner-box {
      flex: 1;
      background-color: #fafafa;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
      align-content: left;
    }
  
    /* 🆕 Profile photo section */
    .photo-container {
      position: relative;
      width: 120px;
      height: 120px;
      margin-bottom: 20px;
    }
  
    .photo-circle {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #ddd;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      color: #555;
      font-size: 14px;
    }
  
    /* 🆕 Edit pencil icon */
    .edit-icon {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 30px;
      height: 30px;
      background-color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 6px rgba(0,0,0,0.2);
      cursor: pointer;
    }
  
    .edit-icon img {
      width: 16px;
      height: 16px;
    }
  
    /* 🆕 Form fields */
    form {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
  
    label {
      font-weight: 500;
      font-size: 14px;
    }
  
    input {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      outline: none;
      font-size: 14px;
    }
  
    form {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.name-row {
  display: flex;
  gap: 10px;
}

.name-field {
  flex: 1;
  display: flex;
  flex-direction: column;
}

label {
  font-weight: 500;
  font-size: 14px;
  margin-bottom: 4px;
}

input {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 6px;
  outline: none;
  font-size: 14px;
  box-sizing: border-box;
}
    @media (max-width: 900px) {
      .form-grid {
        flex-direction: column;
      }
    }
  </style>
  
  <div class="container">
    <!-- Sidebar -->
    <div class="sidebar">
      <h2>Sidebar</h2>
      <p>Navigation, profile links, etc.</p>
    </div>
  
    <!-- Main Form Container -->
    <div class="main-form">
      <h2>Profile</h2>
  
      <div class="form-grid">
  
          <!-- 🆕 Profile Photo -->
          <div class="photo-container">
            <div class="photo-circle">Photo</div>
            <div class="edit-icon">
              <!-- <img src={pencilIcon} alt="Edit" /> -->
            </div>
          </div>
  
          <!-- 🆕 Basic Info Section -->
            <div class="inner-box">
            <h3>Basic Info</h3>

          <!-- 🆕 Form Fields -->
          <form>
            <div class="name-row">
                <div class="name-field">
                  <label for="firstName">First Name</label>
                  <input id="firstName" type="text" placeholder="John" />
                </div>
            
                <div class="name-field">
                  <label for="lastName">Last Name</label>
                  <input id="lastName" type="text" placeholder="Doe" />
                </div>
              </div>
            
            <label for="email">Email</label>
            <input id="email" type="email" placeholder="john.doe@email.com" />
  
            <label for="phone">Phone Number</label>
            <input id="phone" type="tel" placeholder="+1 234 567 890" />
          </form>
        </div>
  
        <!-- Second box placeholder (unchanged) -->
        <div class="inner-box">
          <h3>Account Settings</h3>
          <p>Coming soon...</p>
        </div>
      </div>
    </div>
  </div>
  