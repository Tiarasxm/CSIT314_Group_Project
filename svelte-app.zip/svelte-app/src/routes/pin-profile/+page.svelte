<script>
    import editIcon from '$lib/assets/edit.svg?url';
  </script>
  
  <style>
    .container {
      display: flex;
      height: 100vh;
      width: 100vw;
      gap: 20px;
      padding: 20px;
      box-sizing: border-box;
      background-color: #f0f2f5;
    }
  
    .sidebar {
      flex: 1;
      background-color: white;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
  
    .main-form {
      flex: 3;
      background-color: white;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
      gap: 20px;
      box-sizing: border-box;
    }
  
    .form-grid {
      display: flex;
      gap: 20px;
      flex: 1;
    }
  
    .inner-box {
      flex: 1;
      background-color: #fafafa;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
      position: relative;
    }
  
    .inner-box h3 {
      font-weight: 400;
      font-size: 16px;
      margin-bottom: 12px;
    }
  
    /* Basic Info Photo */
    .photo-container {
      position: relative;
      width: 150px;
      height: 150px;
      margin: 0 auto 20px auto;
    }
  
    .photo-circle {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #ddd;
    }
  
    .edit-icon {
      position: absolute;
      bottom: 0;
      right: 0;
      width: 28px;
      height: 28px;
      background-color: white;
      border: 2px solid orange;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 6px rgba(0,0,0,0.2);
      cursor: pointer;
    }
  
    .edit-icon img {
      width: 16px;
      height: 16px;
    }
  
    form {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
  
    .name-row {
      display: flex;
      gap: 10px;
    }
  
    .name-field {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
  
    label {
      font-weight: 500;
      font-size: 14px;
    }
  
    input, select, textarea {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
      outline: none;
      box-sizing: border-box;
      color: #333;
    }
  
    input::placeholder,
    textarea::placeholder {
      color: #999;
    }
  
    input:disabled {
      background-color: #e0e0e0;
      cursor: not-allowed;
    }
  
    .password-wrapper {
      position: relative;
      display: flex;
      align-items: center;
    }
  
    .password-wrapper input {
      flex: 1;
      padding-right: 100px;
    }
  
    .change-password {
      position: absolute;
      right: 10px;
      color: orange;
      font-weight: 500;
      font-size: 12px;
      cursor: pointer;
    }
  
    .phone-wrapper {
      display: flex;
      gap: 0;
    }
  
    .phone-prefix {
      padding: 10px;
      border: 1px solid #ccc;
      border-right: none;
      border-radius: 6px 0 0 6px;
      font-size: 14px;
      color: #333;
      background-color: white;
    }
  
    .phone-input {
      flex: 1;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 0 6px 6px 0;
      outline: none;
      font-size: 14px;
    }
  
    .phone-input::placeholder {
      color: #999;
    }
  
    textarea {
      resize: vertical;
      min-height: 120px;
    }
  
    /* Personal Details adjustments */
    .inner-box.personal {
      flex: 1;
      background-color: #fafafa;
      border-radius: 10px;
      padding: 40px 20px 20px 20px; /* push content down */
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
      position: relative;
    }
  
    .personal-details {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
  
    .label-input-gap {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
  
    .save-button {
      align-self: flex-end;
      margin-top: 20px;
      padding: 16px 28px;
      background-color: orange;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 500;
      font-size: 14px;
    }
  
    @media (max-width: 900px) {
      .form-grid {
        flex-direction: column;
      }
    }
  </style>
  
  <div class="container">
    <div class="sidebar">
      <h2>Sidebar</h2>
      <p>Navigation, profile links, etc.</p>
    </div>
  
    <div class="main-form">
      <div class="form-grid">
        <!-- Basic Information -->
        <div class="inner-box">
          <div class="photo-container">
            <div class="photo-circle"></div>
            <div class="edit-icon">
              <img src={editIcon} alt="Edit" />
            </div>
          </div>
  
          <h3>Basic Information</h3>
  
          <form>
            <div class="name-row">
              <div class="name-field">
                <label for="firstName">First Name</label>
                <input id="firstName" type="text" placeholder="Enter your first name" />
              </div>
              <div class="name-field">
                <label for="lastName">Last Name</label>
                <input id="lastName" type="text" placeholder="Enter your last name" />
              </div>
            </div>
  
            <label for="email">Email</label>
            <input id="email" type="email" placeholder="john.doe@email.com" disabled />
  
            <label for="password">Password</label>
            <div class="password-wrapper">
              <input id="password" type="password" placeholder="****" />
              <span class="change-password">Change password</span>
            </div>
  
            <label for="phone">Phone Number</label>
            <div class="phone-wrapper">
              <span class="phone-prefix">+65</span>
              <input id="phone" class="phone-input" type="tel" placeholder="Enter your phone number" />
            </div>
          </form>
        </div>
  
        <!-- Personal Details -->
        <div class="inner-box personal">
          <h3>Personal Details</h3>
          <div class="personal-details">
            <div class="label-input-gap">
              <label>Date of Birth</label>
              <input type="text" placeholder="DD/MM/YYYY" />
            </div>
  
            <div class="label-input-gap">
              <label>Gender</label>
              <select>
                <option value="" disabled selected>Select your gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
  
            <div class="label-input-gap">
              <label>Language</label>
              <input type="text" placeholder="Enter preferred language" />
            </div>
  
            <div class="label-input-gap">
              <label>Address</label>
              <input type="text" placeholder="Enter your address" />
            </div>
  
            <div class="label-input-gap">
              <label>Medical Condition</label>
              <textarea placeholder="Relevant health notes..."></textarea>
            </div>
  
            <button class="save-button">Save</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  