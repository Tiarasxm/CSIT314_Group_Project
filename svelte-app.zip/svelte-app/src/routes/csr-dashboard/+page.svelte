<script>
  import DashboardCard from '$lib/components/DashboardCard.svelte';
  import Sidebar from '$lib/components/Sidebar.svelte';
  import { goto } from '$app/navigation';

  // Dynamic data
  let name = "Alex"; // this can come from backend
  let newRequestsCount = 3;
  let activeAssignmentsCount = 5;
  let shortlistsCount = 2;
  let completedServicesCount = 7;

  // Icon imports
  import RequestIcon from '$lib/assets/request.svg';
  import AssignmentIcon from '$lib/assets/assignment.svg';
  import ShortlistIcon from '$lib/assets/shortlist.svg';
  import CompletedIcon from '$lib/assets/completed-task.svg';

  // Navigate to page
  const navigate = (path) => goto(path);
</script>

<style>
  .container {
    display: flex;
    min-height: 100vh;
    gap: 20px;
    padding: 50px;
    box-sizing: border-box;
    background-color: #f0f0f0;
  }

  .sidebar {
    width: 220px;
  }

  .right-container {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  /* Gradient greeting box */
  .box-2 {
    border-radius: 15px;
    padding: 30px;
    background: linear-gradient(135deg, #ff8a00, #ffc766);
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 15px;
  }

  .box-2 h4 {
    margin: 0;
    font-size: 1.8em;
    font-weight: 400;
  }

  .box-2 p {
    font-size: 1em;
    font-weight: 400;
    margin: 0;
  }

  .submit-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background-color: white;
    color: #ff8a00;
    border: none;
    padding: 12px 22px;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
    font-size: 1em;
    width: fit-content;
    align-self: flex-start;
  }

  /* Dashboard grid */
  .box-5 {
    display: grid;
    flex: 1;
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: repeat(2, 1fr);
    gap: 20px;
  }

  @media (max-width: 768px) {
    .container {
      flex-direction: column;
      padding: 20px;
    }

    .sidebar,
    .right-container {
      width: 100%;
    }

    .box-5 {
      grid-template-columns: 1fr;
      grid-template-rows: repeat(4, auto);
    }
  }
</style>

<div class="container">
  <div class="sidebar">
    <Sidebar />
  </div>

  <div class="right-container">
    <!-- Box 2: Greeting / submit request -->
    <div class="box-2">
      <h4>Hi, {name}! Here’s what happening today.</h4>
      <p>Let us know what you need. Our team and volunteers are here to help you every step of the way.</p>
      <button class="submit-btn" on:click={() => navigate('/new-equest')}>
        All New Request
      </button>
    </div>

    <!-- Box 5: Dashboard cards -->
    <div class="box-5">
      <DashboardCard
        icon={RequestIcon}
        title="New Requests"
        subtitle="Awaiting review and matching"
        count={newRequestsCount}
        link="/new-request"
      />

      <DashboardCard
        icon={AssignmentIcon}
        title="Active Assignments"
        subtitle="Current requests you’re managing"
        count={activeAssignmentsCount}
        link="/active-assignment"
      />

      <DashboardCard
        icon={ShortlistIcon}
        title="My Shortlists"
        subtitle="Current requests you’re managing"
        count={shortlistsCount}
        link="/shortlist"
      />

      <DashboardCard
        icon={CompletedIcon}
        title="Completed Services"
        subtitle="All completed requests"
        count={completedServicesCount}
        link="/completed-services"
      />
    </div>
  </div>
</div>
