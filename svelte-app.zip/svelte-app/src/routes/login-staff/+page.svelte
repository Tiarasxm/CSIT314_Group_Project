<script>
    import googleIcon from '$lib/assets/google-logo.png?url';
    import { goto } from '$app/navigation';
  
    let email = '';
    let password = '';
  
    function handleLogin() {
      console.log({ email, password });
    }
  
    function goToClientPortal() {
      goto('/client-portal'); // navigate to client portal
    }
  </script>
  
  <style>
    .container {
      display: flex;
      height: 100vh;
      width: 100vw;
    }
  
    .left-side {
      flex: 1;
      background-color: #f5f5dc;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
  
    .card {
      background-color: white;
      border-radius: 12px;
      padding: 50px 35px; /* more padding for a spacious look */
      width: 100%;
      max-width: 360px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      display: flex;
      flex-direction: column;
      align-items: stretch;
      box-sizing: border-box;
    }
  
    h2 {
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 25px;
    }
  
    label {
      margin-bottom: 3px; 
      font-weight: 500;
      text-align: left;
    }
  
    input {
      width: 100%;
      padding: 10px 12px; /* more horizontal padding for placeholders */
      margin-bottom: 12px; 
      border-radius: 6px;
      border: 1px solid #ccc;
      outline: none;
      box-sizing: border-box;
    }
  
    .forgot-link {
      display: block;
      text-align: right;
      font-size: 12px;
      font-weight: bold;
      text-decoration: none;
      margin-bottom: 20px;
    }
  
    .main-btn {
      width: 100%;
      padding: 10px;
      background-color: #FFA500;
      color: white;
      font-weight: bold;
      border-radius: 6px;
      border: none;
      cursor: pointer;
      margin-bottom: 25px;
    }
  
    .small-text {
      font-size: 12px;
      color: #555;
      margin-bottom: 15px;
    }
  
    .portal-btn {
      width: 100%;
      padding: 10px;
      background-color: white;
      color: #FFA500;
      border: 1px solid #FFA500;
      font-weight: bold;
      border-radius: 6px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  
    .portal-btn span {
      margin-left: 8px;
    }
  
    .right-side {
      flex: 1;
      background-color: #FFA500;
    }
  </style>
  
  <div class="container">
    <!-- Left side -->
    <div class="left-side">
      <div class="card">
        <h2>Log In</h2>
  
        <label for="email">Email</label>
        <input
          id="email"
          type="email"
          placeholder="Enter your email"
          bind:value={email} />
  
        <label for="password">Password</label>
        <input
          id="password"
          type="password"
          placeholder="Enter your password"
          bind:value={password} />
  
        <a href="#" class="forgot-link">Forgot your password?</a>
  
        <button class="main-btn" on:click={handleLogin}>Log In</button>
  
        <div class="small-text">
          Are you a person in need of help or a CSR Rep?
        </div>
  
        <button class="portal-btn" on:click={goToClientPortal}>
          Go to Client Portal <span>→</span>
        </button>
      </div>
    </div>
  
    <!-- Right side -->
    <div class="right-side"></div>
  </div>
  