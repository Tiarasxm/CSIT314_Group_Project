<script>
	import favicon from '$lib/assets/favicon.svg';
	import "../app.css";  
  </script>
  
  <style global>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

    html, body {
        font-family: 'Poppins', sans-serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    * {
        font-family: inherit; /* ensures all elements inherit Poppins */
        box-sizing: inherit;
    }
</style>


  <!-- Render page content -->
  <slot />
  