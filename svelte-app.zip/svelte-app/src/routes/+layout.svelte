<script>
	import favicon from '$lib/assets/favicon.svg';
	import "../app.css";  
  </script>
  
  <svelte:head>
	<link rel="icon" href={favicon} />
  </svelte:head>
  
  <!-- Render page content -->
  <slot />
  