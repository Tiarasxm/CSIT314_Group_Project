<script>
    import googleIcon from '$lib/assets/google-logo.png?url';
    import { goto } from '$app/navigation';
  
    let email = '';
    let password = '';
  
    function handleLogin() {
      console.log({ email, password });
    }
  
    function continueWithGoogle() {
      console.log("Google login clicked");
      goto('/create-password');
    }
  
    function goToStaffPortal() {
      goto('/login-staff'); 
    }
  </script>
  
  <style>
    .container {
      display: flex;
      height: 100vh;
      width: 100vw;
    }
  
    .left-side {
      flex: 1;
      background-color: #f5f5dc;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
  
    .card {
      background-color: white;
      border-radius: 12px;
      padding: 40px 30px;
      width: 100%;
      max-width: 360px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      display: flex;
      flex-direction: column;
      gap: 12px; 
      box-sizing: border-box;

    }
  
    h2 {
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 10px;
      margin-top: 20px;
    }
  
    label {
      font-weight: 500;
      text-align: left;
      margin-bottom: 4px;
    }
  
    input {
      width: 100%;
      padding: 10px 3px;
      border-radius: 6px;
      border: 1px solid #ccc;
      outline: none;
    }
  
    .forgot-link {
      text-align: right;
      font-size: 12px;
      font-weight: bold;
      text-decoration: none;
      margin-bottom: 0;
    }
  
    .main-btn {
      width: 100%;
      padding: 10px;
      background-color: #FFA500;
      color: white;
      font-weight: bold;
      border-radius: 6px;
      border: none;
      cursor: pointer;
    }
  
    .small-text {
      text-align: center;
      font-size: 12px;
      color: #888;
    }
  
    .small-text a {
      font-weight: bold;
      color: #ed9121;
      text-decoration: none;
    }
  
    .divider {
      display: flex;
      align-items: center;
      text-align: center;
      color: #bbb;
      font-size: 12px;
      gap: 10px;
    }
  
    .divider hr {
      flex: 1;
      border: none;
      border-top: 1px solid #bbb;
    }
  
    .google-btn {
      width: 100%;
      padding: 10px;
      background-color: white;
      color: #555;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
  
    .google-btn img {
      width: 18px;
      height: 18px;
    }
  
    .admin-section {
      display: flex;
      flex-direction: column;
      gap: 10px; 
      margin-top: 10px; 
    }
  
    .portal-btn {
      width: 100%;
      padding: 10px;
      background-color: white;
      color: #FFA500;
      border: 1px solid #FFA500;
      font-weight: bold;
      border-radius: 6px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 5px;
    }
  
    .right-side {
      flex: 1;
      background-color: #FFA500;
    }
  </style>
  
  <div class="container">
    <div class="left-side">
      <div class="card">
        <h2>Log In</h2>
  
        <label for="email">Email</label>
        <input id="email" type="email" placeholder="Enter your email" bind:value={email} />
  
        <label for="password">Password</label>
        <input id="password" type="password" placeholder="Enter your password" bind:value={password} />
  
        <a href="#" class="forgot-link">Forgot your password?</a>
  
        <button class="main-btn" on:click={handleLogin}>Log In</button>
  
        <div class="small-text">
          Don't have an account? <a href="/sign-up">Sign Up</a>
        </div>
  
        <div class="divider">
          <hr /><span>or</span><hr />
        </div>
  
        <button class="google-btn" on:click={continueWithGoogle}>
          <img src={googleIcon} alt="Google" /> Continue with Google
        </button>
  
        <div class="admin-section">
          <div class="small-text">Are you an admin or manager?</div>
          <button class="portal-btn" on:click={goToStaffPortal}>
            Go to Staff Portal <span>→</span>
          </button>
        </div>
      </div>
    </div>
  
    <div class="right-side"></div>
  </div>
  