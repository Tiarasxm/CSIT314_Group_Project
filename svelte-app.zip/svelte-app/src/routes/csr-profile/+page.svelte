<script>
    let firstName = '';
    let lastName = '';
    let email = '';
    let password = '';
    let phone = '';
  
    function saveProfile() {
      console.log({ firstName, lastName, email, password, phone });
    }
  </script>
  
  <style>
    .profile-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 25px;
      padding: 20px;
    }
  
    /* Profile photo section */
    .photo-wrapper {
      position: relative;
      width: 120px;
      height: 120px;
    }
  
    .photo-circle {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #ddd; /* grey placeholder */
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      color: #555;
      font-size: 14px;
    }
  
    .edit-icon {
      position: absolute;
      right: 0;
      bottom: 0;
      width: 30px;
      height: 30px;
      border-radius: 50%;
      border: 2px solid #FFA500; /* orange border */
      background-color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
  
    .edit-icon img {
      width: 16px;
      height: 16px;
    }
  
    /* Form styling */
    .form {
      display: flex;
      flex-direction: column;
      gap: 15px;
      width: 100%;
      max-width: 600px; /* stretch horizontally */
    }
  
    label {
      font-weight: 500;
      font-size: 14px;
      margin-bottom: 4px;
    }
  
    input {
      width: 100%;
      padding: 10px 12px;
      border-radius: 6px;
      border: 1px solid #ccc;
      outline: none;
      font-size: 14px;
      box-sizing: border-box;
    }
  
    input::placeholder {
      color: #aaa; /* faded grey placeholder */
    }
  
    /* First + Last name row */
    .name-row {
      display: flex;
      gap: 10px;
    }
  
    .name-field {
      flex: 1;
      display: flex;
      flex-direction: column;
    }
  
    /* Phone input with fixed prefix */
    .phone-wrapper {
      display: flex;
      gap: 5px;
      align-items: center;
    }
  
    .phone-prefix {
      padding: 10px 12px;
      border-radius: 6px;
      border: 1px solid #ccc;
      background-color: #f0f0f0;
      font-size: 14px;
      white-space: nowrap;
    }
  
    .phone-input {
      flex: 1;
      padding: 10px 12px;
      border-radius: 6px;
      border: 1px solid #ccc;
      outline: none;
      font-size: 14px;
      box-sizing: border-box;
    }
  
    .save-btn {
      margin-top: 10px;
      padding: 12px;
      border: none;
      border-radius: 6px;
      background-color: #FFA500;
      color: white;
      font-weight: bold;
      cursor: pointer;
    }
  </style>
  
  <div class="profile-container">
    <!-- Profile photo section -->
    <div class="photo-wrapper">
      <div class="photo-circle">Photo</div>
      <div class="edit-icon">
        ✎
        <!-- Or use <img src={pencilIcon} alt="Edit" /> -->
      </div>
    </div>
  
    <!-- Profile form -->
    <div class="form">
      <h1>Profile</h1>
  
      <!-- First & Last Name Row -->
      <div class="name-row">
        <div class="name-field">
          <label for="firstName">First Name</label>
          <input id="firstName" type="text" placeholder="Enter your first name" bind:value={firstName} />
        </div>
        <div class="name-field">
          <label for="lastName">Last Name</label>
          <input id="lastName" type="text" placeholder="Enter your last name" bind:value={lastName} />
        </div>
      </div>
  
      <label for="email">Email</label>
      <input id="email" type="email" placeholder="Enter your email" bind:value={email} />
  
      <label for="password">Password</label>
      <input id="password" type="password" placeholder="Enter your password" bind:value={password} />
  
      <label for="phone">Phone Number</label>
      <div class="phone-wrapper">
        <div class="phone-prefix">+65</div>
        <input class="phone-input" id="phone" type="tel" placeholder="Enter your number" bind:value={phone} />
      </div>
  
      <button class="save-btn" on:click={saveProfile}>Save Profile</button>
    </div>
  </div>
  