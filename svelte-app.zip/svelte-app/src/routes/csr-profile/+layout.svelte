<script>
    import Sidebar from '$lib/components/Sidebar.svelte';
  </script>
  
  <style>
    .layout {
      display: flex;
      height: 100vh;
      width: 100vw;
      padding: 20px; /* adds spacing around the content */
      box-sizing: border-box;
      background-color: #f0f2f5;
      gap: 20px; /* space between sidebar and main content */
    }
  
    .sidebar-wrapper {
      flex: 1;
      max-width: 250px; /* optional: control width */
    }
  
    .content {
      flex: 3;
      background-color: white;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      overflow-y: auto;
    }
  </style>
  
  <div class="layout">
    <div class="sidebar-wrapper">
      <Sidebar />
    </div>
  
    <div class="content">
      <slot />
    </div>
  </div>
  