<script>
    import { createEventDispatcher } from "svelte";
    import PlusIcon from "$lib/assets/plus.svg";
  
    export let currentCategories = [];
    const dispatch = createEventDispatcher();
    let inputs = [...currentCategories];
  
    function addInput() {
      inputs = [...inputs, ""];
    }
  
    function clearInput(index) {
      inputs[index] = "";
    }
  
    function cancel() {
      dispatch("close");
    }
  
    function save() {
      const cleaned = inputs.filter(v => v.trim() !== "");
      dispatch("save", { categories: cleaned });
      dispatch("close");
    }
  </script>
  
  <style>
    .card {
      position: absolute;
      bottom: 70px;
      left: 20px;
      right: 20px;
      background: white;
      color: #333;
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.25);
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      animation: slide-up 0.3s ease;
    }
  
    @keyframes slide-up {
      from { transform: translateY(30px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
  
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  
    .card-header h4 {
      font-weight: 400;
      font-size: 0.9em;
      color: #666;
      margin: 0;
    }
  
    .card-header img {
      width: 18px;
      height: 18px;
      cursor: pointer;
    }
  
    .input-row {
      display: flex;
      align-items: center;
      gap: 8px;
    }
  
    .input-number {
      color: #E59101;
      font-weight: bold;
      width: 18px;
      text-align: right;
    }
  
    input {
      flex: 1;
      padding: 8px 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 0.95em;
    }
  
    .clear-btn {
      background: none;
      border: none;
      color: #E59101;
      font-weight: bold;
      cursor: pointer;
      font-size: 1em;
    }
  
    .card-footer {
      display: flex;
      justify-content: space-between;
      margin-top: 15px;
    }
  
    .cancel-btn {
      border: 2px solid #E59101;
      background: transparent;
      color: #E59101;
      padding: 8px 18px;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
    }
  
    .save-btn {
      border: none;
      background: #E59101;
      color: white;
      padding: 8px 18px;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
    }
  </style>
  
  <div class="card">
    <div class="card-header">
      <h4>Current Service Category</h4>
      <img src={PlusIcon} alt="Add" on:click={addInput} />
    </div>
  
    {#each inputs as input, i}
      <div class="input-row">
        <span class="input-number">{i + 1}.</span>
        <input bind:value={inputs[i]} placeholder="Enter category..." />
        <button class="clear-btn" on:click={() => clearInput(i)}>×</button>
      </div>
    {/each}
  
    <div class="card-footer">
      <button class="cancel-btn" on:click={cancel}>Cancel</button>
      <button class="save-btn" on:click={save}>Save</button>
    </div>
  </div>
  