<script>
    import { createEventDispatcher } from "svelte";
    import PlusIcon from "$lib/assets/plus.svg";
    import CompletedTaskIcon from "$lib/assets/completed-task.svg";
    import FilterIcon from "$lib/assets/filter.svg";
  
    const dispatch = createEventDispatcher();
    let selectedFilter = "all";
    let inputs = [];
    let showCategoryCard = false;
    let showFilterCard = false;
  
    // Dummy data placeholders
    let userStats = {
      totalCSR: 56,
      accountsCreated: 124,
      activeUsers: 87,
      totalPins: 342,
      suspended: 9
    };
  
    let allRequests = [
      { label: "Total Requests", value: 340, change: "+8%" },
      { label: "Unassigned", value: 14, change: "-3%" },
      { label: "Pending", value: 52, change: "+2%" },
      { label: "Completed", value: 274, change: "+5%" }
    ];
  
    let requestByCategory = [
      { label: "Household Support", value: 78, change: "+3%" },
      { label: "Transport Help", value: 102, change: "-1%" },
      { label: "Emotional Support", value: 65, change: "+7%" }
    ];
  
    function addInput() {
      if (inputs.length < 4) inputs = [...inputs, ""];
    }
  
    function removeInput(index) {
      inputs = inputs.filter((_, i) => i !== index);
    }
  
    function cancel() {
      showCategoryCard = false;
    }
  
    function save() {
      const cleaned = inputs.filter((v) => v.trim() !== "");
      console.log("Saved Categories:", cleaned);
      showCategoryCard = false;
    }
  
    function toggleCategoryCard() {
      showCategoryCard = !showCategoryCard;
    }
  
    function toggleFilterCard() {
      showFilterCard = !showFilterCard;
    }
  
    function logOut() {
      console.log("Logging out...");
    }
  
    function generatePDF() {
      console.log("Generating PDF...");
    }
  </script>
  
  <style>
    .container {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      padding: 40px;
      gap: 20px;
      box-sizing: border-box;
    }
  
    /* Orange header */
    .box-1 {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 30px;
      border-radius: 15px;
      background: linear-gradient(135deg, #ff8a00, #ffc766);
      color: white;
    }
  
    .header-text h2 {
      margin: 0;
      font-weight: 300;
      font-size: 1.8em;
    }
  
    .header-text p {
      margin: 0;
      font-weight: 300;
      font-size: 0.95em;
      color: rgba(255, 255, 255, 0.9);
    }
  
    .logout-btn {
      padding: 12px 24px;
      border: 1px solid white;
      border-radius: 8px;
      background-color: transparent;
      color: white;
      font-weight: bold;
      cursor: pointer;
    }
  
    .lower-row {
      display: flex;
      flex: 1;
      gap: 20px;
    }
  
    /* MSC Box */
    .box-2 {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      background-color: white;
      border-radius: 15px;
      padding: 25px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      position: relative;
    }
  
    .box-2-header {
      display: flex;
      align-items: center;
      gap: 10px;
    }
  
    .box-2-header h3 {
      font-weight: 500;
      color: #333;
    }
  
    .msc-list {
      margin-top: 10px;
      padding-left: 20px;
      color: #555;
      font-size: 0.95em;
    }
  
    .edit-category-btn {
      align-self: center;
      width: 100%;
      text-align: center;
      padding: 10px 20px;
      border-radius: 8px;
      background: transparent;
      border: 2px solid #E59101;
      color: #E59101;
      font-weight: 500;
      cursor: pointer;
      font-size: 1em;
    }
  
    .category-card {
      position: absolute;
      bottom: 70px;
      left: 0;
      right: 0;
      margin: 0 auto;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 12px;
      z-index: 10;
    }
  
    .category-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  
    .category-header h4 {
      font-size: 0.95em;
      color: #777;
      font-weight: 400;
    }
  
    .category-header img {
      width: 18px;
      height: 18px;
      cursor: pointer;
    }
  
    .input-row {
      display: flex;
      align-items: center;
      gap: 8px;
    }
  
    .input-number {
      color: #E59101;
      font-weight: 600;
      width: 16px;
      text-align: right;
    }
  
    .input-row input {
      flex: 1;
      padding: 8px 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
  
    .input-row button {
      background: none;
      border: none;
      color: #E59101;
      font-weight: bold;
      cursor: pointer;
      font-size: 1em;
    }
  
    .card-footer {
      display: flex;
      justify-content: space-between;
      margin-top: 15px;
    }
  
    .cancel-btn {
      padding: 8px 18px;
      border-radius: 6px;
      border: 2px solid #E59101;
      background: transparent;
      color: #E59101;
      font-weight: bold;
      cursor: pointer;
    }
  
    .save-btn {
      padding: 8px 18px;
      border-radius: 6px;
      border: none;
      background-color: #E59101;
      color: white;
      font-weight: bold;
      cursor: pointer;
    }
  
    /* Platform Reports */
    .box-3 {
      flex: 2.4;
      display: flex;
      flex-direction: column;
      padding: 25px;
      border-radius: 15px;
      background-color: white;
      color: #333;
      position: relative;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
  
    .box-3-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
  
    .box-3-header h3 {
      font-weight: 500;
      color: #333;
    }
  
    .filter-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 8px;
      border-radius: 8px;
      background: transparent;
      border: 2px solid #E59101;
      cursor: pointer;
    }
  
    .filter-card {
      position: absolute;
      top: 55px;
      right: 25px;
      background: white;
      color: #333;
      border-radius: 10px;
      padding: 10px 15px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.15);
      width: 130px;
      z-index: 10;
    }
  
    .filter-card h4 {
      font-weight: 400;
      font-size: 0.85em;
      color: #777;
      margin: 0 0 8px;
    }
  
    .filter-option {
      margin-bottom: 6px;
      font-size: 0.9em;
    }
  
    .inner-box-container {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
  
    .stat-box {
      background: #f9f9f9;
      border-radius: 10px;
      padding: 18px 22px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
  
    .stat-columns {
      display: flex;
      gap: 20px;
    }
  
    .stat-box,
    .stat-columns .stat-box {
      flex: 1;
    }
  
    .two-col {
      display: flex;
      justify-content: space-between;
      gap: 30px;
    }
  
    .stat-column {
      display: flex;
      flex-direction: column;
      gap: 10px;
      flex: 1;
    }
  
    .stat-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  
    .stat-label {
      color: #777;
      font-size: 0.85em;
    }
  
    .stat-value {
      color: #000;
      font-weight: 600;
      font-size: 0.95em;
    }
  
    .change {
      color: #E59101;
      font-weight: 500;
      font-size: 0.85em;
      margin-left: 5px;
    }
  
    .export-btn {
      align-self: center;
      margin-top: 25px;
      padding: 12px 24px;
      border-radius: 8px;
      background: transparent;
      border: 2px solid #E59101;
      color: #E59101;
      font-weight: 500;
      cursor: pointer;
      font-size: 1.05em;
    }
  </style>
  
  <div class="container">
    <div class="box-1">
      <div class="header-text">
        <h2>Welcome, Platform Manager!</h2>
        <p>Here's today's platform overview</p>
      </div>
      <button class="logout-btn" on:click={logOut}>Log Out</button>
    </div>
  
    <div class="lower-row">
      <!-- MSC -->
      <div class="box-2">
        <div>
          <div class="box-2-header">
            <img src={CompletedTaskIcon} alt="Completed Task Icon" />
            <h3>Managed Service Categories</h3>
          </div>
  
          <ul class="msc-list">
            <li>Household Support</li>
            <li>Transport Help</li>
            <li>Emotional Support</li>
          </ul>
  
          {#if showCategoryCard}
            <div class="category-card">
              <div class="category-header">
                <h4>Current Service Category</h4>
                <img src={PlusIcon} alt="Add" on:click={addInput} />
              </div>
  
              {#each inputs as input, i}
                <div class="input-row">
                  <span class="input-number">{i + 1}.</span>
                  <input type="text" bind:value={inputs[i]} placeholder="Enter category..." />
                  <button on:click={() => removeInput(i)}>×</button>
                </div>
              {/each}
  
              <div class="card-footer">
                <button class="cancel-btn" on:click={cancel}>Cancel</button>
                <button class="save-btn" on:click={save}>Save</button>
              </div>
            </div>
          {/if}
        </div>
  
        <button class="edit-category-btn" on:click={toggleCategoryCard}>
          Edit Categories
        </button>
      </div>
  
      <!-- Platform Reports -->
      <div class="box-3">
        <div class="box-3-header">
          <h3>Platform Reports</h3>
          <button class="filter-btn" on:click={toggleFilterCard}>
            <img src={FilterIcon} alt="Filter Icon" />
          </button>
        </div>
  
        {#if showFilterCard}
          <div class="filter-card">
            <h4>Filter by</h4>
            {#each ['all', '24h', '7d', '1m', '1y'] as f}
              <div class="filter-option">
                <input type="radio" id={f} name="filter" value={f} bind:group={selectedFilter} />
                <label for={f}>
                  {f === 'all' ? 'All time' : 
                   f === '24h' ? 'In 24 hours' :
                   f === '7d' ? 'In 7 days' :
                   f === '1m' ? 'In 1 month' : 'In 1 year'}
                </label>
              </div>
            {/each}
          </div>
        {/if}
  
        <div class="inner-box-container">
          <!-- User Statistics -->
          <div class="stat-box">
            <div class="two-col">
              <div class="stat-column">
                <div class="stat-item"><span class="stat-label">Total CSR Reps</span><span class="stat-value">{userStats.totalCSR}</span></div>
                <div class="stat-item"><span class="stat-label">Accounts Created</span><span class="stat-value">{userStats.accountsCreated}</span></div>
                <div class="stat-item"><span class="stat-label">Active Users</span><span class="stat-value">{userStats.activeUsers}</span></div>
              </div>
              <div class="stat-column">
                <div class="stat-item"><span class="stat-label">Total PINs</span><span class="stat-value">{userStats.totalPins}</span></div>
                <div class="stat-item"><span class="stat-label">Suspended</span><span class="stat-value">{userStats.suspended}</span></div>
              </div>
            </div>
          </div>
  
          <!-- All Requests & Requests by Category side by side -->
          <div class="stat-columns">
            <div class="stat-box">
              <div class="stat-column">
                {#each allRequests as item}
                  <div class="stat-item">
                    <span class="stat-label">{item.label}</span>
                    <div style="display:flex; align-items:center; gap:6px;">
                      <span class="stat-value">{item.value}</span>
                      <span class="change">{item.change}</span>
                    </div>
                  </div>
                {/each}
              </div>
            </div>
  
            <div class="stat-box">
              <div class="stat-column">
                {#each requestByCategory as item}
                  <div class="stat-item">
                    <span class="stat-label">{item.label}</span>
                    <div style="display:flex; align-items:center; gap:6px;">
                      <span class="stat-value">{item.value}</span>
                      <span class="change">{item.change}</span>
                    </div>
                  </div>
                {/each}
              </div>
            </div>
          </div>
        </div>
  
        <button class="export-btn" on:click={generatePDF}>Export Reports</button>
      </div>
    </div>
  </div>
  