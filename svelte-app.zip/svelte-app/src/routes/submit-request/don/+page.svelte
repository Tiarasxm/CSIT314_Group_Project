<script>
    import { goto } from '$app/navigation';
    let selectedCategory = '';
  
    const goBack = () => goto('/dashboard');
    const goNext = () => goto('/submit-request/add-no');
  </script>
  
  <style>
  /* ========== STEPPER BOX ========== */
  .stepper-box {
    background-color: white;
    width: 800px; 
    border-radius: 12px;
    margin: 20px auto;
    padding: 10px 0;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .stepper {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 28px;
    font-family: 'Poppins', sans-serif;
    font-size: 13px;
  }
  
  .circle {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    font-weight: 700;
  }
  
  .circle.active {
    background-color: orange;
    color: white;
    border: none;
  }
  
  .circle.inactive {
    background-color: #fff;
    color: #aaa;
    border: 2px solid #ccc;
  }
  
  .step-label {
    font-weight: 600;
    font-size: 14px;
  }
  
  .step-label.active {
    color: #333;
  }
  
  .step-label.inactive {
    color: #aaa;
  }
  
  .step {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  
  .arrow {
    font-size: 14px;
    font-weight: 700;
    color: #555;
  }
  
  /* ========== FORM BOX ========== */
  .red-box-content {
    display: flex;
    width: 950px; 
    height: 320px; 
    background-color: #ffffff;
    padding: 10px;
    border-radius: 12px;
    box-sizing: border-box;
    margin: 0 auto;
    overflow: hidden;
  }
  
  /* LEFT COLUMN */
  .red-box-left {
    display: flex;
    flex-direction: column;
    width: 66%;
    height: 100%;
    padding: 14px;
    box-sizing: border-box;
    gap: 6px;
    position: relative;
  }
  
  .red-box-left h2 {
    margin: 0 0 8px 0;
    font-size: 18px;
    font-weight: 500;
  }
  
  .red-box-left .subtitle {
    margin: 0;
    font-size: 15px;
    color: #555;
  }
  
  .radio-group {
    display: flex;
    gap: 12px;
    margin-top: 2px;
  }
  
  .radio-group label {
    display: flex;
    align-items: center;
    font-size: 13px;
    cursor: pointer;
  }
  
  .radio-group input[type="radio"] {
    margin-right: 4px;
  }
  
  .red-box-left h3 {
    margin: 8px 10px 2px 0;
    font-size: 15px;
    font-weight: 200;
    color: #555;
  }
  
  .red-box-left textarea {
    width: 100%;
    height: 60px; 
    padding: 6px;
    font-size: 13px;
    border: 1px solid #ccc;
    border-radius: 8px;
    resize: none;
    color: #333;
    box-sizing: border-box;
    margin-bottom: 20px;
  }
  
  .red-box-left textarea::placeholder {
    color: #aaa;
  }
  
  /* RIGHT COLUMN */
  .red-box-right {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    width: 34%;
    height: 100%;
    padding: 14px;
    box-sizing: border-box;
    gap: 14px;
    position: relative;
  }
  
  .red-box-right .field {
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-bottom: 15px;
  }
  
  .red-box-right label {
    font-size: 15px;
    color: #555;
    margin-bottom: 5px;
  }
  
  .red-box-right select {
    padding: 6px 10px;
    border-radius: 6px;
    border: 1px solid #ccc;
    background-color: #fff;
    font-size: 13px;
    cursor: pointer;
  }
  
  /* ========== BUTTONS ========== */
  .back-btn, .next-btn {
    position: absolute;
    bottom: 10px;
    padding: 10px 20px;
    font-size: 14px;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.2s;
  }
  
  .back-btn {
    left: 10px;
    border: 2px solid orange;
    background: none;
    color: orange;
  }
  
  .back-btn:hover {
    background: orange;
    color: white;
    transform: translateY(-1px);
  }
  
  .next-btn {
    right: 25px;
    border: none;
    background: orange;
    color: white;
  }
  
  .next-btn:hover {
    background: #ff9900;
    transform: translateY(-1px);
  }
  </style>
  
  <!-- STEPPER BOX -->
  <div class="stepper-box">
    <div class="stepper">
      <div class="step">
        <div class="circle active">1</div>
        <span class="step-label active">Description of Need</span>
      </div>
      <span class="arrow">&gt;</span>
      <div class="step">
        <div class="circle inactive">2</div>
        <span class="step-label inactive">Additional Needs</span>
      </div>
    </div>
  </div>
  
  <!-- FORM BOX -->
  <div class="red-box-content">
    <!-- LEFT COLUMN -->
    <div class="red-box-left">
      <h2>Please tell us more about what you need</h2>
      <p class="subtitle">Select your category</p>
  
      <div class="radio-group">
        <label><input type="radio" bind:group={selectedCategory} value="household" /> Household</label>
        <label><input type="radio" bind:group={selectedCategory} value="transport" /> Transport</label>
        <label><input type="radio" bind:group={selectedCategory} value="emotional" /> Emotional Support</label>
      </div>
  
      <h3>Describe your need*</h3>
      <textarea placeholder="eg. I need help cleaning my home after returning from the hospital"></textarea>
  
      <button class="back-btn" on:click={goBack}>Back</button>
    </div>
  
    <!-- RIGHT COLUMN -->
    <div class="red-box-right">
      <div class="field">
        <label>Preferred date</label>
        <select>
          <option disabled selected>Sat, Nov 13</option>
          <option>Sun, Nov 14</option>
          <option>Mon, Nov 15</option>
        </select>
      </div>
  
      <div class="field">
        <label>Preferred time</label>
        <select>
          <option disabled selected>10:30 PM</option>
          <option>11:00 PM</option>
          <option>11:30 PM</option>
        </select>
      </div>
  
      <button class="next-btn" on:click={goNext}>Next</button>
    </div>
  </div>
  