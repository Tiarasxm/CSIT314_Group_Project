
<script>

  import { page } from '$app/stores';
  import { goto } from '$app/navigation';
  import { get } from 'svelte/store';
  
  export let data;
  const { title = "Submit new request ", showBack = true } = data;
  import backIcon from "$lib/assets/back.svg";

  const goBack = () => {
    const path = get(page).url.pathname;
    if (path === '/don') {
      goto('/dashboard');
    } else if (path === '/add-no') {
      goto('/don');
    } else {
      history.back();
    }
  };


</script>
  
  <style>
    /* Fixed header */
    .header-container {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      background: #F2F1ED;
      padding: 100px 24px 16px; /* top padding for header */
      z-index: 10;
    }
  
    .header {
      display: flex;
      align-items: center;
      position: relative;
    }
  
    .back-btn {
      position: absolute;
      top: 0;
      left: 0;
      background: none;
      border: none;
      cursor: pointer;
      padding-left: 40px  ;
    }
  
    .back-btn img {
      width: 32px;
      height: 32px;
    }
  
    .title {
      flex: 1;
      text-align: center;
      font-size: 26px;
      font-weight: 500;
      margin: 0;
    }
  
    /* Body container fills remaining space below header */
    .body-container {
      padding: 5px;
      padding-top: 200px; 
      padding-bottom: 300px;
      box-sizing: border-box;
      background-color: #F2F1ED;
    }
  
    /* Inner box that fills body container and centers content */
    .inner-box {
      flex: 1; /* fill all remaining space */
      display: flex;
      justify-content: center; /* center horizontally */
      align-items: center;     /* center vertically */
      width: 100%;
    }
  
    /* Red box container */
    .red-box {
      width: 1000px;
      height: 450px;
      background: red-box(245, 239, 239);
      background-color: white;
      border-radius: 16px;
      padding: 10px;
      box-sizing: border-box;
    }
  </style>
  

    
    <!-- Fixed header -->
    <div class="header-container">
        <div class="header">
        {#if showBack}
            <button class="back-btn" on:click={goBack}>
            <img src={backIcon} alt="Back" />
            </button>
        {/if}
        <h2 class="title">{title}</h2>
        </div>
    </div>
    
    
    <!-- Body container (full height below header) -->
    <div class="body-container">
        <div class="inner-box">
        <div class="red-box">
            <slot />
        </div>
        </div>
    </div>