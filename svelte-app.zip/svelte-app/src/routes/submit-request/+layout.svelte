<script>
    // layout logic here if needed
  </script>
  
  <header class="page-header">
    <h1>Submit new request</h1>
  </header>
  
  <main class="page-body">
    <slot /> <!-- child pages render here -->
  </main>
  
  <style>
    .page-header {
      text-align: center;
      margin-top: 2rem;
      font-size: 1.5rem;
      font-weight: bold;
    }
  
    .page-body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: calc(100vh - 100px);
    }
  </style>
  