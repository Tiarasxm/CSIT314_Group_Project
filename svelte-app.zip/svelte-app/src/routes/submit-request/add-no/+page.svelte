<script>
    import { goto } from '$app/navigation';
    import FileUploadIcon from '$lib/assets/file-upload.svg';
    import PopupCard from '$lib/components/PopupCard.svelte';

    let selectedCategory = '';
    let uploadedFile = null;
    let showPopup = false; // controls popup visibility

    // Navigate back
    const goBack = () => goto('/submit-request/don');

    // Handle file selection
    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (!file) return;

        const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
        const maxSizeMB = 10;

        if (!allowedTypes.includes(file.type)) {
            alert('Unsupported file type!');
            return;
        }

        if (file.size / 1024 / 1024 > maxSizeMB) {
            alert('File is too large! Max 10MB.');
            return;
        }

        uploadedFile = file;
    };

    // Handle form submission and show popup
    const handleSubmit = () => {
        showPopup = true;
    };
</script>


<div>
    <div class="stepper">
        <div class="step">
            <div class="circle">1</div>
            <span class="step-label">Description of Need</span>
        </div>

        <span class="arrow">&gt;</span>

        <div class="step">
            <div class="circle">2</div>
            <span class="step-label">Additional Needs</span>
        </div>
    </div>    

    <div class="red-box-left">
        <h4>Additional Notes</h4>
        <p class="subtitle main">Anything else you'd like us to know</p>
        <p class="subtitle optional">Optional: Attach Supporting Files</p>

        <!-- File Upload Box -->
        <div class="file-upload">
            <input type="file" id="fileInput" on:change={handleFileChange} accept=".jpg,.jpeg,.png,.pdf" />
            <label for="fileInput">
                <img src={FileUploadIcon} alt="Add File" class="file-icon" />
                <span class="add-text">Add File</span>
                <span class="supported-text">Supported: JPG, PNG, PDF (max 10MB)</span>
                {#if uploadedFile}
                    <span class="file-name">{uploadedFile.name}</span>
                {/if}
            </label>
        </div>

        <!-- Buttons -->
        <button type="button" class="back-btn" on:click={goBack}>Back</button>
        <button type="button" class="submit-btn" on:click={handleSubmit}>Submit</button>

        <!-- Popup -->
        <PopupCard bind:show={showPopup} />
    </div>
</div>

<style>

.stepper {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 40px;
    margin-top: 40px;
    margin-bottom: 30px;
    font-family: 'Poppins', sans-serif;
}

.step {
    display: flex;
    align-items: center;
    gap: 8px;
}

.circle {
    width: 30px;
    height: 30px;
    background-color: orange;
    color: white;
    font-weight: 700;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
}

.step-label {
    font-weight: 600;
    color: #333;
    font-size: 16px;
}

.arrow {
    color: #ccc;
    font-size: 16px;
    font-weight: 700;
}

.red-box-left {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 350px;
    padding: 5px 25px 50px 25px;
    box-sizing: border-box;
    position: relative;
    background-color: FFFFFF;
    border-radius: 16px;
    font-family: poppins;
}

.red-box-left h4 {
    margin: 3px 0 0 0; 
    font-size: 18px;
    font-weight: 500;
    color: black;
}

.red-box-left .subtitle {
    margin-bottom: 20px;
    font-size: 14px;
}

.red-box-left .subtitle.main {
    color: #555;
    margin-bottom: 8px;
}

.red-box-left .subtitle.optional {
    color: #888;
    margin-bottom: 6px;
}

.file-upload {
    margin-top: 0px;
    border: 2px dashed #888;
    border-radius: 12px;
    height: 100px;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    cursor: pointer;
    transition: background 0.2s, border-color 0.2s;
}

.file-upload:hover {
    background: #ffe5e5;
    border-color: #b71c1c;
}

.file-upload input[type="file"] {
    display: none;
}

.file-upload label {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    gap: 6px;
    cursor: pointer;
}

.file-upload .file-icon {
    width: 36px;
    height: 36px;
}

.file-upload .add-text {
    font-weight: 600;
    color: #888;
    font-size: 16px;
}

.file-upload .supported-text {
    font-size: 12px;
    color: #555;
}

.file-upload .file-name {
    margin-top: 6px;
    font-size: 14px;
    font-weight: 500;
    color: #333;
}

.back-btn, .submit-btn {
    position: absolute;
    bottom: 15px;
    padding: 10px 20px;
    margin-bottom: 30px;
    font-size: 14px;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.2s;
}

.back-btn {
    left: 25px;
    border: 2px solid orange;
    background: none;
    color: orange;
}

.back-btn:hover {
    background: orange;
    color: white;
    transform: translateY(-1px);
}

.submit-btn {
    right: 25px;
    border: none;
    background: orange;
    color: white;
}

.submit-btn:hover {
    background: #ff9900;
    transform: translateY(-1px);
}
</style>
