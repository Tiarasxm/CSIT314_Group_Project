<script>
  import PageHeader from "$lib/components/PageHeader.svelte";
  import AssignVolunteer from "$lib/components/AssignVolunteer.svelte";
  import homeIcon from "$lib/assets/home.svg";

  let shortlist = [
    {
      id: 1,
      headerLines: ["Household Support", "Request ID: 124"],
      iconSrc: homeIcon,
      name: "Rachelle Wong",
      photoSrc: "",
      volunteer: "John Doe",
      mobile: "+65 1234 5678",
      time: "6:30 PM",
      date: "11 Nov 2025",
      note: "I need help cleaning my home after returning from the hospital. Preferably sometime this weekend. I need help cleaning my home after returning from the hospital. Preferably sometime this weekend.",
      createdOn: "02 Nov 2025"
    },
    {
      id: 2,
      headerLines: ["Household Support", "Request ID: 124"],
      iconSrc: homeIcon,
      name: "Rachelle Wong",
      photoSrc: "",
      volunteer: "John Doe",
      mobile: "+65 1234 5678",
      time: "6:30 PM",
      date: "11 Nov 2025",
      note: "I need help cleaning my home after returning from the hospital. Preferably sometime this weekend. I need help cleaning my home after returning from the hospital. Preferably sometime this weekend.",
      createdOn: "02 Nov 2025"
    },
    {
      id: 3,
      headerLines: ["Household Support", "Request ID: 124"],
      iconSrc: homeIcon,
      name: "Rachelle Wong",
      photoSrc: "",
      volunteer: "John Doe",
      mobile: "+65 1234 5678",
      time: "6:30 PM",
      date: "11 Nov 2025",
      note: "I need help cleaning my home after returning from the hospital. Preferably sometime this weekend. I need help cleaning my home after returning from the hospital. Preferably sometime this weekend.",
      createdOn: "02 Nov 2025"
    }
  ];

  let selectedCardId = null;

  function editCard(card) {
    selectedCardId = card.id;
  }

  function closeAssignVolunteer() {
    selectedCardId = null;
  }
</script>

<PageHeader title="Active Assignments" showBack={true} />

<div class="container">
  {#each shortlist as card}
    <div class="card">
      <!-- Header -->
      <div class="header-box">
        <img src={card.iconSrc} alt="icon" class="header-icon" />
        <div class="header-text">
          <p class="title">{card.headerLines[0]}</p>
          <p class="subtitle">{card.headerLines[1]}</p>
        </div>
      </div>

      <!-- Profile Section -->
      <div class="profile-section">
        {#if card.photoSrc}
          <img src={card.photoSrc} alt={card.name} class="photo" />
        {:else}
          <div class="photo placeholder"></div>
        {/if}
        <p class="name">{card.name}</p>
      </div>

      <!-- Volunteer & Mobile (50/50) -->
      <div class="info-row">
        <div class="info-box half">
          <h5>Volunteer:</h5>
          <p>{card.volunteer}</p>
        </div>
        <div class="info-box half">
          <h5>Mobile:</h5>
          <p>{card.mobile}</p>
        </div>
      </div>

      <!-- Time & Date -->
      <div class="info-row">
        <div class="info-box half">
          <p class="bold">{card.time}</p>
          <p class="faded">{card.date}</p>
        </div>
        <div class="info-box half"></div>
      </div>

      <!-- Note -->
      <div class="note-box">
        <h5>Note:</h5>
        <p class="note-text">{card.note}</p>
      </div>

      <!-- Created On -->
      <p class="created-on">Created on {card.createdOn}</p>

      <!-- Edit Button -->
      <div class="button-wrapper">
        <button class="edit-btn" on:click={() => editCard(card)}>Edit details</button>
        {#if selectedCardId === card.id}
          <div class="assign-popup">
            <AssignVolunteer {card} on:close={closeAssignVolunteer} />
          </div>
        {/if}
      </div>
    </div>
  {/each}
</div>

<style>
  .container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: space-around;
    padding: 20px;
    background: #FDFAF3;
  }

  .card {
    width: 320px;
    background: #fff;
    padding: 16px;
    border-radius: 16px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    gap: 12px;
    font-family: 'Poppins', sans-serif;
    font-size: 14px;
    position: relative; /* required for popup positioning */
  }

  .header-box {
    display: flex;
    align-items: center;
    background: #FDFAF3;
    padding: 10px;
    border-radius: 12px;
    gap: 12px;
  }

  .header-icon { width: 32px; height: 32px; }
  .header-text .title { font-weight: 600; margin: 0; }
  .header-text .subtitle { margin: 0; color: #888; }

  .profile-section {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
  }

  .photo { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; }
  .photo.placeholder { background: #ccc; }
  .name { font-weight: 600; margin: 0; color: #555; }

  .info-row { display: flex; gap: 12px; margin-bottom: 8px; }
  .info-box { display: flex; flex-direction: column; gap: 2px; }
  .info-box.half { flex: 1; }
  .info-box h5 { margin: 0; font-weight: 600; font-size: 14px; }
  .info-box p { margin: 0; font-size: 14px; }
  .bold { font-weight: 600; }
  .faded { color: #555; }

  .note-box h5 { margin: 0 0 4px 0; font-weight: 600; }
  .note-text { margin: 0; color: #888; }

  .created-on { text-align: center; color: #555; font-size: 14px; }

  .button-wrapper {
    position: relative;
    width: 100%;
  }

  .edit-btn {
    width: 100%;
    padding: 10px 0;
    font-size: 14px;
    border-radius: 8px;
    border: 2px solid #E59000;
    background: white;
    color: #E59000;
    font-weight: 600;
    cursor: pointer;
    margin-top: 8px;
  }

  /* Popup positioning */
  .assign-popup {
    position: absolute;
    bottom: 100%; /* above the button */
    left: 50%;
    transform: translateX(-50%);
    z-index: 10;
    margin-bottom: 10px;
  }

  @media(max-width: 650px){
    .container { flex-direction: column; align-items: center; }
    .info-row { flex-direction: column; }
  }
</style>
