<script>
    import PageHeader from "$lib/components/PageHeader.svelte";
    import homeIcon from "$lib/assets/home.svg";
  
    let shortlist = [
      {
        id: 1,
        headerLines: ["Household Support", "Request ID: 124"],
        iconSrc: homeIcon,
        name: "Rachelle Wong",
        photoSrc: "",
        volunteer: "John Doe",
        mobile: "+65 1234 5678",
        time: "6:30 PM",
        date: "11 Nov 2025",
        note: "I need help cleaning my home after returning from the hospital. Preferably sometime this weekend.",
        created: "02 Nov 2025"
      },
      {
        id: 2,
        headerLines: ["Household Support", "Request ID: 125"],
        iconSrc: homeIcon,
        name: "Sarah Kim",
        photoSrc: "",
        volunteer: "Jane Smith",
        mobile: "+65 9876 5432",
        time: "2:00 PM",
        date: "12 Nov 2025",
        note: "Follow up required.",
        created: "03 Nov 2025"
      },
      {
        id: 3,
        headerLines: ["Household Support", "Request ID: 126"],
        iconSrc: homeIcon,
        name: "David Chen",
        photoSrc: "",
        volunteer: "Alex Tan",
        mobile: "+65 1122 3344",
        time: "10:00 AM",
        date: "13 Nov 2025",
        note: "Urgent request.",
        created: "04 Nov 2025"
      }
    ];
  </script>
  
  <div class="page-wrapper">
    <PageHeader title="Pending Requests" showBack={true} />
  
    <div class="container">
      {#each shortlist as card, index}
        <div class="card">
          <!-- Header -->
          <div class="header-box">
            <img src={card.iconSrc} alt="icon" class="header-icon" />
            <div class="header-text">
              <p class="title">{card.headerLines[0]}</p>
              <p class="subtitle">{card.headerLines[1]}</p>
            </div>
          </div>
  
          <!-- Time & Date -->
          <div class="info-row left-align">
            <div class="info-box half">
              <p class="bold">{card.time}</p>
              <p class="faded">{card.date}</p>
            </div>
            <div class="info-box half"></div>
          </div>
  
          <!-- Status (Fixed to Confirmed) -->
          <div class="info-row left-align">
            <div class="info-box half">
              <p class="status-label">Status:</p>
              <p class="status" style="color:#158C1A">Confirmed</p>
            </div>
            <div class="info-box half"></div>
          </div>
  
          <!-- Note -->
          <div class="note-box left-align">
            <h5>Note:</h5>
            <p class="note-text">{card.note}</p>
          </div>
  
          <!-- Created Date -->
          <p class="created-date">Created on {card.created}</p>
  
          <!-- Shortlist Counter inside card -->
          <div class="card-shortlist-counter">
            {shortlist.length} Shortlisted
          </div>
        </div>
      {/each}
    </div>
  </div>
  
  <style>
    html, body {
      margin: 0;
      padding: 0;
      height: 100%;
      background: #FDFAF3;
      font-family: 'Poppins', sans-serif;
    }
  
    .page-wrapper {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      background: #FDFAF3;
      position: relative;
    }
  
    .container {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: space-around;
      padding: 20px;
      background: #FDFAF3;
    }
  
    .card {
      position: relative; /* needed for counter positioning */
      width: 320px;
      background: #fff;
      padding: 16px 24px;
      border-radius: 16px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      display: flex;
      flex-direction: column;
      gap: 8px;
      font-size: 14px;
    }
  
    .header-box {
      display: flex;
      align-items: center;
      background: #FDFAF3;
      padding: 8px;
      border-radius: 12px;
      gap: 12px;
    }
  
    .header-icon { width: 32px; height: 32px; }
    .header-text .title { font-weight: 600; margin: 0; }
    .header-text .subtitle { margin: 0; color: #888; }
  
    .profile-section {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
    }
  
    .photo { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; }
    .photo.placeholder { background: #ccc; }
    .name { font-weight: 600; margin: 0; color: #555; }
  
    .info-row { display: flex; gap: 8px; margin-bottom: 4px; }
    .info-box { display: flex; flex-direction: column; gap: 1px; }
    .info-box.half { flex: 1; }
    .info-box h5 { margin: 0; font-weight: 600; font-size: 14px; }
    .info-box p { margin: 0; font-size: 14px; }
    .bold { font-weight: 600; }
    .faded { color: #555; }
    .status-label { margin: 0; font-weight: 600; }
    .status { margin: 0; font-weight: 600; }
  
    .note-box h5 { margin: 0 0 4px 0; font-weight: 600; }
    .note-text { margin: 0; color: #888; }
  
    .created-date {
      font-size: 12px;
      color: #aaa;
      text-align: center;
    }
  
    /* Shift left-aligned elements slightly to the right */
    .left-align {
      margin-left: 8px; /* adjust as needed */
    }
  
    /* Counter inside card */
    .card-shortlist-counter {
      position: absolute;
      bottom: 12px;
      right: 16px;
      color: #888;
      font-size: 12px;
      font-weight: 500;
    }
  
    @media(max-width: 650px){
      .container { flex-direction: column; align-items: center; }
      .info-row { flex-direction: column; }
    }
  </style>
  