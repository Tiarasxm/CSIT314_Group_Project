<script>
	let password = '';
	let confirmPassword = '';

	function handleCreatePassword() {
		console.log({ password, confirmPassword });
	}
</script>

<style>
.card {
	background-color: white;
	border-radius: 12px;
	padding: 40px; 
	width: 100%;
	max-width: 400px;
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
	display: flex;
	flex-direction: column;
	gap: 15px; 
	box-sizing: border-box;
}

.card h2 {
	font-size: 24px;
	font-weight: bold;
	margin: 0 0 15px 0; 
}

/* Closer label + input */
.form-group {
	display: flex;
	flex-direction: column;
	margin-bottom: 5px; 
}

.form-group label {
	margin-bottom: 5px; 
	font-weight: 500;
}

.form-group input {
	width: 100%;
	padding: 10px;
	border-radius: 6px;
	border: 1px solid #ccc;
	outline: none;
	box-sizing: border-box;
}

.signup-btn {
	width: 100%;
	padding: 10px;
	background-color: #ffa500;
	color: white;
	font-weight: bold;
	border-radius: 6px;
	border: none;
	cursor: pointer;
}
</style>

<div class="container" style="display: flex; height: 100vh; width: 100vw;">
	<!-- Left beige side -->
	<div class="left-side" style="flex:1; background-color:#f5f5dc; display:flex; justify-content:center; align-items:center;">
		<div class="card">
			<h2>Create Password</h2>

			<!-- Create Password -->
			<div class="form-group">
				<label for="password">Create Password</label>
				<input id="password" type="password" placeholder="Enter your password" bind:value={password} />
			</div>

			<!-- Confirm Password -->
			<div class="form-group">
				<label for="confirmPassword">Confirm Password</label>
				<input id="confirmPassword" type="password" placeholder="Re-enter your password" bind:value={confirmPassword} />
			</div>

			<button class="signup-btn" on:click={handleCreatePassword}>Sign Up</button>
		</div>
	</div>

	<!-- Right orange side -->
	<div class="right-side" style="flex:1; background-color:#ffa500;"></div>
</div>
