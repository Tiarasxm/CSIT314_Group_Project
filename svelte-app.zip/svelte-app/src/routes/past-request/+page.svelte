<script>
    import PageHeader from "$lib/components/PageHeader.svelte";
    import homeIcon from "$lib/assets/home.svg";
  
    let shortlist = [
      {
        id: 1,
        headerLines: ["Household Support", "Request ID: 124"],
        iconSrc: homeIcon,
        name: "Rachelle Wong",
        photoSrc: "",
        volunteer: "John Doe",
        mobile: "+65 1234 5678",
        time: "6:30 PM",
        date: "11 Nov 2025",
        status: "Completed",
        note: "I need help cleaning my home after returning from the hospital. Preferably sometime this weekend.",
        created: "02 Nov 2025"
      },
      {
        id: 2,
        headerLines: ["Household Support", "Request ID: 125"],
        iconSrc: homeIcon,
        name: "Sarah Kim",
        photoSrc: "",
        volunteer: "Jane Smith",
        mobile: "+65 9876 5432",
        time: "2:00 PM",
        date: "12 Nov 2025",
        status: "Completed",
        note: "Follow up required.",
        created: "03 Nov 2025"
      },
      {
        id: 3,
        headerLines: ["Household Support", "Request ID: 126"],
        iconSrc: homeIcon,
        name: "David Chen",
        photoSrc: "",
        volunteer: "Alex Tan",
        mobile: "+65 1122 3344",
        time: "10:00 AM",
        date: "13 Nov 2025",
        status: "Completed",
        note: "Urgent request.",
        created: "04 Nov 2025"
      }
    ];
  
    const statusColor = (status) =>
      status === "Completed"
        ? "blue"
        : status === "Confirmed"
        ? "green"
        : status === "Pending"
        ? "orange"
        : "#555";
  </script>
  
  <div class="page-wrapper">
    <PageHeader title="Past Requests" showBack={true} />
  
    <div class="container">
      {#each shortlist as card}
        <div class="card">
          <!-- Header -->
          <div class="header-box">
            <img src={card.iconSrc} alt="icon" class="header-icon" />
            <div class="header-text">
              <p class="title">{card.headerLines[0]}</p>
              <p class="subtitle">{card.headerLines[1]}</p>
            </div>
          </div>
  
          <!-- Profile Section -->
          <div class="profile-section">
            {#if card.photoSrc}
              <img src={card.photoSrc} alt={card.name} class="photo" />
            {:else}
              <div class="photo placeholder"></div>
            {/if}
            <p class="name">{card.name}</p>
          </div>
  
          <!-- Volunteer & Mobile -->
          <div class="info-row">
            <div class="info-box half">
              <h5>Volunteer:</h5>
              <p>{card.volunteer}</p>
            </div>
            <div class="info-box half">
              <h5>Mobile:</h5>
              <p>{card.mobile}</p>
            </div>
          </div>
  
          <!-- Time & Date -->
          <div class="info-row">
            <div class="info-box half">
              <p class="bold">{card.time}</p>
              <p class="faded">{card.date}</p>
            </div>
            <div class="info-box half"></div>
          </div>
  
          <!-- Status -->
          <div class="info-row">
            <div class="info-box half">
              <p class="status-label">Status:</p>
              <p class="status" style="color:{statusColor(card.status)}">{card.status}</p>
            </div>
            <div class="info-box half"></div>
          </div>
  
          <!-- Note -->
          <div class="note-box">
            <h5>Note:</h5>
            <p class="note-text">{card.note}</p>
          </div>
  
          <!-- Created Date -->
          <p class="created-date">Created on {card.created}</p>
        </div>
      {/each}
    </div>
  </div>
  
  <style>
    html, body {
    margin: 0;
    padding: 0;
    height: 100%;
    background: #FDFAF3;
    font-family: 'Poppins', sans-serif;
    }

    .page-wrapper {
    display: flex;
    flex-direction: column;
    min-height: 100vh; 
    background: #FDFAF3;
    }

    .container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: space-around;
    padding: 20px;
    background: #FDFAF3;
    }
    .card {
      width: 320px;
      background: #fff;
      padding: 16px;
      border-radius: 16px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      display: flex;
      flex-direction: column;
      gap: 8px;
      font-size: 14px;
    }
  
    .header-box {
      display: flex;
      align-items: center;
      background: #FDFAF3;
      padding: 8px;
      border-radius: 12px;
      gap: 12px;
    }
  
    .header-icon { width: 32px; height: 32px; }
    .header-text .title { font-weight: 600; margin: 0; }
    .header-text .subtitle { margin: 0; color: #888; }
  
    .profile-section {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
    }
  
    .photo { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; }
    .photo.placeholder { background: #ccc; }
    .name { font-weight: 600; margin: 0; color: #555; }
  
    .info-row { display: flex; gap: 8px; margin-bottom: 4px; }
    .info-box { display: flex; flex-direction: column; gap: 1px; }
    .info-box.half { flex: 1; }
    .info-box h5 { margin: 0; font-weight: 600; font-size: 14px; }
    .info-box p { margin: 0; font-size: 14px; }
    .bold { font-weight: 600; }
    .faded { color: #555; }
    .status-label { margin: 0; font-weight: 600; }
    .status { margin: 0; font-weight: 600; }
  
    .note-box h5 { margin: 0 0 4px 0; font-weight: 600; }
    .note-text { margin: 0; color: #888; }
  
    .created-date {
      margin-top: auto;
      font-size: 12px;
      color: #aaa;
      text-align: center;
    }
  
    @media(max-width: 650px){
      .container { flex-direction: column; align-items: center; }
      .info-row { flex-direction: column; }
    }
  </style>
  