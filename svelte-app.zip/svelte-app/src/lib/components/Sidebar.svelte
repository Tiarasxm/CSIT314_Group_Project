<script>
  import HomeIcon from '$lib/assets/home.svg';
  import AssignmentIcon from '$lib/assets/assignment.svg';
  import ProfileIcon from '$lib/assets/profile.svg';

  const menuItems = [
    { name: 'Dashboard', icon: HomeIcon, href: '/dashboard', size: 28 }, // bigger home icon
    { name: 'Announcement', icon: AssignmentIcon, href: '/announcement', size: 20 },
    { name: 'Profile', icon: ProfileIcon, href: '/profile', size: 20 }
  ];

  function logout() {
    console.log('Logging out...');
    // Add actual logout logic here
  }
</script>

<style>
  .sidebar {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
    background-color: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    box-sizing: border-box;
  }

  .top-section {
    display: flex;
    flex-direction: column;
    gap: 30px;
  }

  .logo {
    font-size: 24px;
    font-weight: bold;
    text-align: left;
  }

  .menu {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .menu-item {
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
    color: inherit;
    transition: background 0.2s;
    padding-left: 5px; /* push icons slightly to the left */
  }

  .menu-item:hover {
    background-color: #f5f5f5;
  }

  .menu-item img {
    width: var(--icon-size);
    height: var(--icon-size);
  }

  .logout-btn {
    padding: 12px;
    border: 2px solid #FFA500;
    border-radius: 8px;
    background-color: transparent;
    color: #FFA500;
    font-weight: 600;  /* lighter than before */
    font-size: 1em;    /* slightly smaller */
    cursor: pointer;
    text-align: center;
    transition: background 0.2s, color 0.2s;
  }

  .logout-btn:hover {
    background-color: #FFA500;
    color: white;
  }
</style>

<div class="sidebar">
  <div class="top-section">
    <div class="logo">Logo</div>

    <div class="menu">
      {#each menuItems as item}
        <a class="menu-item" href={item.href} style="--icon-size: {item.size}px">
          <img src={item.icon} alt={item.name + " icon"} />
          <span>{item.name}</span>
        </a>
      {/each}
    </div>
  </div>

  <button class="logout-btn" on:click={logout}>
    Log Out
  </button>
</div>
