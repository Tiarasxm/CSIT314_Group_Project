<script>
    const menuItems = [
      { name: 'Dashboard', icon: '🏠', href: '/dashboard' },
      { name: 'Announcement', icon: '📢', href: '/announcement' },
      { name: 'Profile', icon: '👤', href: '/profile' }
    ];
  
    function logout() {
      console.log('Logging out...');
      // You can add actual logout logic here
    }
  </script>
  
  <style>
    .sidebar {
      display: flex;
      flex-direction: column;
      justify-content: space-between; /* top items and bottom logout button */
      height: 100%;
      background-color: white;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      box-sizing: border-box;
    }
  
    /* Top section with Logo and menu */
    .top-section {
      display: flex;
      flex-direction: column;
      gap: 30px;
    }
  
    .logo {
      font-size: 24px;
      font-weight: bold;
      text-align: left;
    }
  
    .menu {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
  
    .menu-item {
      padding: 10px 15px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 10px;
      text-decoration: none;
      color: inherit;
      transition: background 0.2s;
    }
  
    .menu-item:hover {
      background-color: #f5f5f5;
    }
  
    /* Bottom logout button */
    .logout-btn {
      padding: 12px;
      border: 2px solid #FFA500;
      border-radius: 8px;
      background-color: transparent;
      color: #FFA500;
      font-weight: bold;
      cursor: pointer;
      text-align: center;
      transition: background 0.2s, color 0.2s;
    }
  
    .logout-btn:hover {
      background-color: #FFA500;
      color: white;
    }
  </style>
  
  <div class="sidebar">
    <!-- Top: Logo and Menu -->
    <div class="top-section">
      <div class="logo">Logo</div>
  
      <div class="menu">
        {#each menuItems as item}
          <a class="menu-item" href={item.href}>
            <span>{item.icon}</span>
            <span>{item.name}</span>
          </a>
        {/each}
      </div>
    </div>
  
    <!-- Bottom: Logout -->
    <button class="logout-btn" on:click={logout}>
      Log Out
    </button>
  </div>
  