<script>
    import PlusIcon from "$lib/assets/plus.svg";
    import { createEventDispatcher } from "svelte";
  
    const dispatch = createEventDispatcher();
    let inputs = [];
  
    function addInput() {
      if (inputs.length < 4) inputs = [...inputs, ""];
    }
  
    function removeInput(index) {
      inputs = inputs.filter((_, i) => i !== index);
    }
  
    function cancel() {
      dispatch("close");
    }
  
    function save() {
      const cleaned = inputs.filter((v) => v.trim() !== "");
      dispatch("save", { categories: cleaned });
      dispatch("close");
    }
  </script>
  
  <style>
    .card {
      background-color: white;
      color: #333;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      max-height: 180px; /* enough to show 1-2 inputs initially */
      overflow-y: auto;
      transition: max-height 0.3s ease;
    }
  
    .card.expanded {
      max-height: 320px; /* expands if user adds more */
    }
  
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }
  
    .card-header h4 {
      font-size: 15px;
      font-weight: 400;
      margin: 0;
    }
  
    .card-header img {
      width: 18px;
      height: 18px;
      cursor: pointer;
    }
  
    .input-row {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      gap: 8px;
    }
  
    .input-number {
      font-weight: bold;
      color: #E59101;
      width: 16px;
      text-align: right;
    }
  
    .input-row input {
      flex: 1;
      padding: 8px 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 0.95em;
    }
  
    .input-row button {
      background: none;
      border: none;
      color: #E59101;
      font-weight: bold;
      cursor: pointer;
      font-size: 1em;
      line-height: 1;
    }
  
    .card-footer {
      display: flex;
      justify-content: space-between;
      margin-top: 15px;
    }
  
    .cancel-btn {
      padding: 8px 18px;
      border-radius: 6px;
      border: 2px solid #E59101;
      background-color: transparent;
      color: #E59101;
      font-weight: bold;
      cursor: pointer;
    }
  
    .save-btn {
      padding: 8px 18px;
      border-radius: 6px;
      border: none;
      background-color: #E59101;
      color: white;
      font-weight: bold;
      cursor: pointer;
    }
  </style>
  
  <div class="card {inputs.length > 1 ? 'expanded' : ''}">
    <div class="card-header">
      <h4>Current Service Categories</h4>
      <img src={PlusIcon} alt="Add" on:click={addInput} />
    </div>
  
    {#each inputs as input, index}
      <div class="input-row">
        <span class="input-number">{index + 1}.</span>
        <input placeholder="Add new category here..." bind:value={inputs[index]} />
        <button on:click={() => removeInput(index)}>×</button>
      </div>
    {/each}
  
    <div class="card-footer">
      <button class="cancel-btn" on:click={cancel}>Cancel</button>
      <button class="save-btn" on:click={save}>Save</button>
    </div>
  </div>
  