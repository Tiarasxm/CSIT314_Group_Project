<script>
    import Card from "./Card.svelte";
    export let cards = []; // array of card objects
  </script>
  
  <div class="container">
    {#each cards as card}
      <Card title={card.title} fields={card.fields} />
    {/each}
  </div>
  
  <style>
  .container {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    gap: 16px;
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
  }
  @media (max-width: 600px) {
    .container {
      flex-direction: column;
      align-items: center;
    }
  }
  </style>
  