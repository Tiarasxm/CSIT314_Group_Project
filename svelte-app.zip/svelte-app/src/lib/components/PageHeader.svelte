<script>
    export let title = "Page Title";
    export let showBack = true;
  
    import backIcon from "$lib/assets/back.svg";
    import searchIcon from "$lib/assets/search.svg";
    import filterIcon from "$lib/assets/filter.svg";
  
    const goBack = () => history.back();
  </script>
  
  <div class="header-container">
    <!-- Header Row -->
    <div class="header">
      {#if showBack}
        <button class="back-btn" on:click={goBack}>
          <img src={backIcon} alt="Back" />
        </button>
      {/if}
      <h2 class="title">{title}</h2>
    </div>
  
    <!-- Search Row -->
    <div class="search-row">
      <div class="search-box">
        <img class="search-icon" src={searchIcon} alt="Search" />
        <input type="text" placeholder="Search" />
      </div>
  
      <button class="filter-btn">
        <img src={filterIcon} alt="Filter" />
      </button>
    </div>
  </div>
  
  <style>
    .header-container {
      background: #F2F1ED;
      padding: 12px 24px 8px;
    }
  
    .header {
      display: flex;
      align-items: center;
      position: relative;
      padding-left: 32px;
      padding-top: 32px;
    }
  
    .back-btn {
      background: none;
      border: none;
      cursor: pointer;
      padding: 0;
    }
  
    .back-btn img {
      width: 34px;
      height: 34px;
    }
  
    .title {
    flex: 1;
    text-align: center;
    font-size: 22px;
    font-weight: 600;
    margin-right: 34px; /* match back icon width for perfect centering */
    }
  
    .search-row {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      margin-top: 14px;
      gap: 12px;
    }
  
    .search-box {
      display: flex;
      align-items: center;
      background: white;
      border-radius: 14px;
      padding: 10px 14px;
      border: 1px solid #E2E2E2;
      min-width: 260px;
    }
  
    .search-icon {
      width: 20px;
      margin-right: 10px;
      opacity: 0.8;
    }
  
    input {
      border: none;
      outline: none;
      font-size: 15px;
      width: 100%;
    }
  
    .filter-btn {
      background: white;
      border-radius: 14px;
      padding: 10px 14px;
      border: 1px solid #E2E2E2;
      cursor: pointer;
      height: 42px;
    }
  
    .filter-btn img {
      width: 20px;
      opacity: 0.8;
    }
  </style>
  