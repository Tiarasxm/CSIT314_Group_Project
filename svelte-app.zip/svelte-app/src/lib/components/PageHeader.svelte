<script>
  export let title = "Page Title";
  export let showBack = true;

  import backIcon from "$lib/assets/back.svg";
  import searchIcon from "$lib/assets/search.svg";
  import filterIcon from "$lib/assets/filter.svg";

  let showFilters = false;

  // Filter selections
  let categories = {
    Household: false,
    Transport: false,
    Emotional: false
  };

  let sortBy = "3days";

  const goBack = () => history.back();
  const toggleFilters = () => {
    showFilters = !showFilters;
  };

  const applyFilters = () => {
    // You can handle filter logic here
    showFilters = false; // hide the card
  };
</script>

<div class="header-container">
  <!-- Header Row -->
  <div class="header">
    {#if showBack}
      <button class="back-btn" on:click={goBack}>
        <img src={backIcon} alt="Back" />
      </button>
    {/if}
    <h2 class="title">{title}</h2>
  </div>

  <!-- Search Row -->
  <div class="search-row">
    <div class="search-box">
      <img class="search-icon" src={searchIcon} alt="Search" />
      <input type="text" placeholder="Search" />
    </div>

    <div class="filter-container" style="position: relative;">
      <button class="filter-btn" on:click={toggleFilters}>
        <img src={filterIcon} alt="Filter" />
      </button>

      <!-- Filter Card -->
      {#if showFilters}
        <div class="filter-card">
          <div class="subtitle">Filter by</div>
          <label><input type="checkbox" bind:checked={categories.Household} /> Household</label>
          <label><input type="checkbox" bind:checked={categories.Transport} /> Transport</label>
          <label><input type="checkbox" bind:checked={categories.Emotional} /> Emotional</label>

          <div class="subtitle" style="margin-top: 12px;">Sort by</div>
          <label><input type="radio" name="sort" value="3days" bind:group={sortBy} /> In 3 days</label>
          <label><input type="radio" name="sort" value="7days" bind:group={sortBy} /> In 7 days</label>
          <label><input type="radio" name="sort" value="14days" bind:group={sortBy} /> In 14 days</label>

          <button class="apply-btn" on:click={applyFilters}>Apply</button>
        </div>
      {/if}
    </div>
  </div>
</div>

<style>
  .header-container {
    background: #FDFAF3;
    padding: 12px 24px 8px;
  }

  .header {
    display: flex;
    align-items: center;
    position: relative;
    padding-left: 32px;
    padding-top: 32px;
  }

  .back-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
  }

  .back-btn img {
    width: 34px;
    height: 34px;
  }

  .title {
    flex: 1;
    text-align: center;
    font-size: 22px;
    font-weight: 600;
    margin-right: 34px; 
  }

  .search-row {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    margin-top: 14px;
    gap: 12px;
  }

  .search-box {
    display: flex;
    align-items: center;
    background: white;
    border-radius: 14px;
    padding: 10px 14px;
    border: 1px solid #E2E2E2;
    min-width: 260px;
  }

  .search-icon {
    width: 20px;
    margin-right: 10px;
    opacity: 0.8;
  }

  input[type="text"] {
    border: none;
    outline: none;
    font-size: 15px;
    width: 100%;
  }

  .filter-btn {
    background: white;
    border-radius: 14px;
    padding: 10px 14px;
    border: 1px solid #E2E2E2;
    cursor: pointer;
    height: 42px;
  }

  .filter-btn img {
    width: 20px;
    opacity: 0.8;
  }

  /* Filter Card Styles */
  .filter-card {
    position: absolute;
    top: 50px; /* Below the button */
    right: 0;
    background: white;
    border: 1px solid #E2E2E2;
    border-radius: 12px;
    padding: 16px 20px;
    width: 220px;
    box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
    z-index: 10;
  }

  .filter-card .subtitle {
    font-size: 13px;
    font-weight: 300;
    color: #999999;
    margin-bottom: 8px;
  }

  .filter-card label {
    display: block;
    margin-bottom: 6px;
    font-size: 14px;
    cursor: pointer;
  }

  .filter-card input[type="checkbox"],
  .filter-card input[type="radio"] {
    margin-right: 8px;
  }

  .apply-btn {
    display: block;
    margin: 16px auto 0 auto;
    padding: 8px 20px;
    background: #007BFF;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    cursor: pointer;
  }

  .apply-btn:hover {
    background: #0056b3;
  }
</style>
