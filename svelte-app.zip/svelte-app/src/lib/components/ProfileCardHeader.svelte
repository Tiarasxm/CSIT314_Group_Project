<!-- src/lib/components/ProfileCardHeader.svelte -->
<script>
    export let photoSrc = "";
    export let title = "";
  </script>
  
  <div class="profile-header">
    <img src={photoSrc} alt={title} class="profile-photo" />
    <h4>{title}</h4>
  </div>
  
  <style>
  .profile-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    margin-bottom: 12px;
  }
  
  .profile-photo {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
  }
  </style>
  