<script>
  export let closeAssignCard;

  function handleConfirm() {
    // Any validation or saving logic can go here
    closeAssignCard(); // close popup after confirming
  }
</script>

<div class="assign-card">
  <h3 class="header">Assign Volunteer</h3>

  <div class="field">
    <label for="volunteer-name">Name</label>
    <input id="volunteer-name" type="text" placeholder="Enter volunteer’s name" />
  </div>

  <div class="field">
    <label for="volunteer-mobile">Mobile Number</label>
    <div class="mobile-input">
      <span class="country-code">+65</span>
      <input id="volunteer-mobile" type="text" placeholder="Enter volunteer’s number" />
    </div>
  </div>

  <div class="button-row">
    <button class="close-btn" on:click={closeAssignCard}>Close</button>
    <button class="confirm-btn" on:click={handleConfirm}>Confirm</button>
  </div>
</div>

<style>
  .assign-card { background: white; border-radius: 16px; padding: 24px; width: 320px; display: flex; flex-direction: column; gap: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-family: 'Poppins', sans-serif; }

  .header { margin: 0; font-weight: 300; font-size: 20px; text-align: center; }
  .field { display: flex; flex-direction: column; gap: 4px; }
  .field label { font-weight: 500; font-size: 14px; color: #555; }
  .field input { padding: 8px 12px; border-radius: 8px; border: 1px solid #ccc; font-size: 14px; outline: none; }
  .field input:focus { border-color: #E59000; }

  .mobile-input { display: flex; align-items: center; gap: 8px; }
  .country-code { background: #eee; padding: 8px 12px; border-radius: 8px 0 0 8px; border: 1px solid #ccc; border-right: none; font-size: 14px; }
  .mobile-input input { flex: 1; border-radius: 0 8px 8px 0; border: 1px solid #ccc; border-left: none; padding: 8px 12px; font-size: 14px; }

  .button-row { display: flex; gap: 12px; }
  .button-row button { flex: 1; padding: 10px 0; border-radius: 8px; font-size: 14px; cursor: pointer; }
  .close-btn { background: white; border: 2px solid #E59000; color: #E59000; }
  .confirm-btn { background: #E59000; border: none; color: white; }

  @media(max-width: 400px){ .assign-card { width: 90%; } }
</style>
