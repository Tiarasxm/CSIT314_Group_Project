<script>
    // Props are passed from parent. No hardcoded overriding defaults.
    export let headerLines;
    export let iconSrc;
    export let name;
    export let photoSrc;
  
    export let volunteer;
    export let mobile;
    export let time;
    export let date;
    export let status;
    export let note;
    export let createdOn;
    export let align = "left"; // optional default
    export let expanded = false;
  
    // fallback values for development only
    const defaultData = {
      headerLines: ["Category X", "Option A"],
      iconSrc: "/lib/assets/home.svg",
      name: "Anna Tan",
      photoSrc: "",
      volunteer: "John Doe",
      mobile: "+65 1234 5678",
      time: "6.30 PM",
      date: "11 Nov 2025",
      status: "Completed",
      note: "This is a dummy note.",
      createdOn: "02 Nov 2025"
    };
  
    // use prop if passed, else fallback
    $: headerLines = headerLines ?? defaultData.headerLines;
    $: iconSrc = iconSrc ?? defaultData.iconSrc;
    $: name = name ?? defaultData.name;
    $: photoSrc = photoSrc ?? defaultData.photoSrc;
    $: volunteer = volunteer ?? defaultData.volunteer;
    $: mobile = mobile ?? defaultData.mobile;
    $: time = time ?? defaultData.time;
    $: date = date ?? defaultData.date;
    $: status = status ?? defaultData.status;
    $: note = note ?? defaultData.note;
    $: createdOn = createdOn ?? defaultData.createdOn;
  
    // Dynamic status color
    $: statusColor =
      status === "Completed" ? "blue" :
      status === "Confirmed" ? "green" :
      status === "Pending" ? "orange" :
      "#555";
  </script>
  
  <div class="card {align} {expanded ? 'expanded' : ''}">
    <!-- Header Box -->
    <div class="header-box">
      <img src={iconSrc} alt="icon" class="header-icon" />
      <div class="header-text">
        <p class="title">{headerLines[0]}</p>
        <p class="subtitle">{headerLines[1]}</p>
      </div>
    </div>
  
    <!-- Profile Section -->
    <div class="profile-section {align}">
      {#if photoSrc}
        <img src={photoSrc} alt={name} class="photo" />
      {:else}
        <div class="photo placeholder"></div>
      {/if}
      <div class="profile-text">
        <h5>CSR Rep</h5>
        <p class="name">{name}</p>
      </div>
    </div>
  
    <!-- Volunteer & Mobile Row -->
    <div class="info-row">
      <div class="info-box">
        <h5>Volunteer:</h5>
        <p>{volunteer}</p>
      </div>
      <div class="info-box">
        <h5>Mobile:</h5>
        <p>{mobile}</p>
      </div>
    </div>
  
    <!-- Time & Date Row -->
    <div class="info-row">
      <div class="info-box">
        <p class="bold">{time}</p>
        <p class="faded">{date}</p>
      </div>
      <div class="info-box"></div>
    </div>
  
    <!-- Status Row -->
    <div class="status-row">
      <p class="status-label">Status:</p>
      <p class="status" style="color: {statusColor}">{status}</p>
    </div>
  
    <!-- Note Box -->
    <div class="note-box">
      <h5>Your note:</h5>
      <p class="note-text">{note}</p>
    </div>
  
    <!-- Created On -->
    <p class="created-on">Created on {createdOn}</p>
  </div>

  
  
  <style>
  /* Existing styles unchanged */
  .card {
    flex: 1 1 200px; 
    max-width: 320px;
    min-width: 200px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 16px;
    background-color: #ffffff;
    border-radius: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    font-family: 'Poppins', sans-serif;
  }
  .card.expanded { max-width: 600px; }
  
  /* Header Box */
  .header-box { display: flex; align-items: center; background-color: #FDFAF3; border-radius: 12px; padding: 10px; gap: 12px; }
  .header-icon { width: 32px; height: 32px; }
  .header-text .title { font-size: 16px; font-weight: 600; margin: 0; }
  .header-text .subtitle { font-size: 14px; margin: 0; }
  
  /* Profile Section */
  .profile-section.left { display: flex; flex-direction: row; align-items: center; gap: 12px; }
  .profile-section.center { display: flex; flex-direction: column; align-items: center; gap: 8px; }
  .profile-text h5 { margin: 0; font-weight: 600; font-size: 14px; }
  .profile-text .name { margin: 0; font-weight: 600; font-size: 14px; color: #555; }
  .photo { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; }
  .photo.placeholder { background-color: #ccc; }
  
  /* Info Rows */
  .info-row { display: flex; gap: 16px; margin-bottom: 12px; }
  .info-box { flex: 1; display: flex; flex-direction: column; gap: 4px; }
  .info-box h5 { margin: 0; font-weight: 600; font-size: 14px; }
  .info-box p { margin: 0; font-size: 14px; }
  .bold { font-weight: 600; }
  .faded { color: #555; }
  
  /* Status Row */
  .status-row { display: flex; flex-direction: column; gap: 2px; margin-bottom: 12px; }
  .status-label, .status { font-size: 14px; margin: 0; font-weight: 600; }
  
  /* Note Box */
  .note-box { margin-top: 0; margin-bottom: 12px; }
  .note-box h5 { margin: 0 0 4px 0; font-weight: 600; }
  .note-text { margin: 0; color: #888888; font-size: 14px; }
  
  /* Created On */
  .created-on { text-align: center; color: #555; font-size: 14px; margin-top: 12px; }
  
  /* Responsive */
  @media screen and (max-width: 600px) {
    .info-row { flex-direction: column; }
    .profile-section.left { flex-direction: column; align-items: center; }
  }
  </style>
  