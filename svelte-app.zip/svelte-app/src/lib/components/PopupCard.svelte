<script>
    import SubmittedIcon from '$lib/assets/submitted.svg';
    import { goto } from '$app/navigation';
    export let show = false;
  
    // Close the popup
    const closePopup = () => {
      show = false;
    };
  
    // Navigate back to dashboard
    const backToDashboard = () => {
      goto('/dashboard');
    };
  </script>
  
  {#if show}
    <div class="overlay">
      <div class="card">
        <!-- SVG Image -->
        <img src={SubmittedIcon} alt="Submitted" class="card-image" />
  
        <!-- First line -->
        <p class="title">Your request has been submitted successfully!</p>
  
        <!-- Second line -->
        <p class="subtitle">Our CSR representatives will review it and reach out to you soon.</p>
  
        <!-- Back to dashboard button -->
        <button class="action-btn" on:click={backToDashboard}>Back to dashboard</button>
      </div>
    </div>
  {/if}
  
  <style>
    .overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.4);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }
  
    .card {
      background-color: white;
      border-radius: 16px;
      padding: 30px 20px;
      width: 600px;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 16px;
    }
  
    .card-image {
      width: 80px;
      height: 80px;
      object-fit: contain;
    }
  
    .title {
      font-weight: 500;
      font-size: 24px;
      margin: 0;
    }
  
    .subtitle {
      font-size: 14px;
      color: #555;
      margin: 0;
    }
  
    .action-btn {
      margin-top: 20px;
      background-color: #E59000;
      color: white;
      font-size: 16px;
      font-weight: 600;
      padding: 10px 20px;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      width: 33%;
    }
  
    .action-btn:hover {
      background-color: #d67a00;
    }
  </style>
  