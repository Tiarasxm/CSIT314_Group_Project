<script>
  import { goto } from '$app/navigation';

  export let icon;       // path to SVG
  export let title;      // card title
  export let subtitle;   // second line, faded
  export let count = 0;  // bold number
  export let link = null; // optional link for default "View More"

  const navigate = (path) => goto(path);
</script>

<style>
  .card {
    background-color: #ffffff;
    border-radius: 15px;
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    color: #333;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    min-height: 180px;
  }

  .icon {
    width: 35px;
    height: 35px;
    margin-bottom: 10px;
    align-self: flex-start;
  }

  .text-group {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .title {
    font-size: 1.2em;
    font-weight: 500;
    text-align: left;
  }

  .subtitle {
    font-size: 0.85em;
    color: #888;
    text-align: left;
  }

  .count {
    font-weight: 500;
    font-size: 1.2em;
    text-align: left;
    margin: 10px 0;
  }

  .footer {
    text-align: right;
  }

  .footer a, .footer .view-more {
    color: orange;
    font-weight: 400;
    font-size: 0.8em;
    text-decoration: none;
    cursor: pointer;
  }

  .footer a:hover, .footer .view-more:hover {
    text-decoration: underline;
  }
</style>

<div class="card">
  <img class="icon" src={icon} alt={title + " icon"} />

  <div class="text-group">
    <div class="title">{title}</div>
    <div class="subtitle">{subtitle}</div>
  </div>

  <div class="count">{count}</div>

  <div class="footer">
    <!-- Use custom slot if provided, otherwise fallback to link -->
    <slot>
      {#if link}
        <span class="view-more" on:click={() => navigate(link)}>View more &gt;</span>
      {/if}
    </slot>
  </div>
</div>
