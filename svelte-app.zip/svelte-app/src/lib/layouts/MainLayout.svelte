<script>
    import PageHeader from "$lib/components/PageHeader.svelte";
    export let pageTitle = "";
  </script>
  
  <PageHeader {pageTitle} />
  
  <main>
    <slot />
  </main>
  
  <style>
  main {
    padding-top: 20px;
  }
  </style>
  