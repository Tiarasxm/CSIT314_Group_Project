<script>
    export let title;
    export let showBack = true;
    import PageHeader from "$lib/components/PageHeader.svelte";
  </script>
  
  <div class="page-wrapper">
    <PageHeader {title} {showBack} />
  
    <main class="content-container">
      <div class="grid">
        <slot></slot>
      </div>
    </main>
  </div>
  
  <style>
    .page-wrapper {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      background: #F2F1ED;
    }
  
    .content-container {
      padding: 32 32;
      flex: 1;
      overflow-y: auto;
    }
  
    /* ✅ Three flexible columns that adapt to screen size */
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 24px;
    }
  </style>
  