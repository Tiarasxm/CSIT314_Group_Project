
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/active-assignment" | "/completed-services" | "/csr-dashboard" | "/csr-profile" | "/dashboard" | "/login-staff" | "/login" | "/new-request" | "/past-request" | "/pending" | "/pin-profile" | "/pm-dashboard" | "/shortlist" | "/sign-up-google" | "/sign-up" | "/submit-request" | "/submit-request/add-no" | "/submit-request/don" | "/upcoming";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/active-assignment": Record<string, never>;
			"/completed-services": Record<string, never>;
			"/csr-dashboard": Record<string, never>;
			"/csr-profile": Record<string, never>;
			"/dashboard": Record<string, never>;
			"/login-staff": Record<string, never>;
			"/login": Record<string, never>;
			"/new-request": Record<string, never>;
			"/past-request": Record<string, never>;
			"/pending": Record<string, never>;
			"/pin-profile": Record<string, never>;
			"/pm-dashboard": Record<string, never>;
			"/shortlist": Record<string, never>;
			"/sign-up-google": Record<string, never>;
			"/sign-up": Record<string, never>;
			"/submit-request": Record<string, never>;
			"/submit-request/add-no": Record<string, never>;
			"/submit-request/don": Record<string, never>;
			"/upcoming": Record<string, never>
		};
		Pathname(): "/" | "/active-assignment" | "/active-assignment/" | "/completed-services" | "/completed-services/" | "/csr-dashboard" | "/csr-dashboard/" | "/csr-profile" | "/csr-profile/" | "/dashboard" | "/dashboard/" | "/login-staff" | "/login-staff/" | "/login" | "/login/" | "/new-request" | "/new-request/" | "/past-request" | "/past-request/" | "/pending" | "/pending/" | "/pin-profile" | "/pin-profile/" | "/pm-dashboard" | "/pm-dashboard/" | "/shortlist" | "/shortlist/" | "/sign-up-google" | "/sign-up-google/" | "/sign-up" | "/sign-up/" | "/submit-request" | "/submit-request/" | "/submit-request/add-no" | "/submit-request/add-no/" | "/submit-request/don" | "/submit-request/don/" | "/upcoming" | "/upcoming/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}