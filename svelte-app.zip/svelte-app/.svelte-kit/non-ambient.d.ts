
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/csr-profile" | "/dashboard" | "/login-staff" | "/login" | "/pin-profile" | "/request" | "/request/pending" | "/request/pending/confirmed" | "/sign-up-google" | "/sign-up" | "/submit-request" | "/submit-request/add-no" | "/submit-request/don" | "/upcoming";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/csr-profile": Record<string, never>;
			"/dashboard": Record<string, never>;
			"/login-staff": Record<string, never>;
			"/login": Record<string, never>;
			"/pin-profile": Record<string, never>;
			"/request": Record<string, never>;
			"/request/pending": Record<string, never>;
			"/request/pending/confirmed": Record<string, never>;
			"/sign-up-google": Record<string, never>;
			"/sign-up": Record<string, never>;
			"/submit-request": Record<string, never>;
			"/submit-request/add-no": Record<string, never>;
			"/submit-request/don": Record<string, never>;
			"/upcoming": Record<string, never>
		};
		Pathname(): "/" | "/csr-profile" | "/csr-profile/" | "/dashboard" | "/dashboard/" | "/login-staff" | "/login-staff/" | "/login" | "/login/" | "/pin-profile" | "/pin-profile/" | "/request" | "/request/" | "/request/pending" | "/request/pending/" | "/request/pending/confirmed" | "/request/pending/confirmed/" | "/sign-up-google" | "/sign-up-google/" | "/sign-up" | "/sign-up/" | "/submit-request" | "/submit-request/" | "/submit-request/add-no" | "/submit-request/add-no/" | "/submit-request/don" | "/submit-request/don/" | "/upcoming" | "/upcoming/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}