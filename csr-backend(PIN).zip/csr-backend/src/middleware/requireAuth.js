import jwt from 'jsonwebtoken'

/** Internal: extract token from header/cookie/query (query allowed only in dev) */
function getToken(req) {
  const auth = req.headers.authorization || ''
  const fromHeader = auth.startsWith('Bearer ') ? auth.slice(7) : null
  const fromCookie = req.cookies?.token || null
  const fromQuery =
    process.env.NODE_ENV !== 'production' ? req.query?.token || null : null
  return fromHeader || fromCookie || fromQuery || null
}

/** Internal: normalize payload into a consistent shape for req.user */
function normalizeUser(payload = {}) {
  const userId = payload.userId || payload.sub || payload.id || null
  const name =
    payload.name ||
    [payload.firstName, payload.lastName].filter(Boolean).join(' ') ||
    null
  return {
    userId,
    name,
    role: payload.role || null,
    email: payload.email || null,
    // keep raw for anything else that might be needed
    _raw: payload,
  }
}

/**
 * Optional auth: if a token is present and valid, sets req.user; otherwise leaves it undefined.
 * Never sends a 401. Use this as a global middleware (app.use(attachAuth))
 * so endpoints can fall back to JWT-scoped queries without breaking anonymous pages.
 */
export function attachAuth(req, _res, next) {
  try {
    const token = getToken(req)
    if (!token) return next()

    const secret = process.env.JWT_SECRET
    if (!secret) {
      // don’t block the request; just continue without user if misconfigured
      return next()
    }

    const decoded = jwt.verify(token, secret, {
      // small clock skew tolerance (optional)
      clockTolerance: 5,
    })
    req.user = normalizeUser(decoded)
    return next()
  } catch (_err) {
    // invalid/expired token → ignore and continue unauthenticated
    return next()
  }
}

/**
 * Strict auth: requires a valid token. Sends 401 on missing/invalid token.
 * Use this for protected routes (create/update/delete, profile changes, etc.)
 */
export function requireAuth(req, res, next) {
  try {
    const token = getToken(req)
    if (!token) {
      return res.status(401).json({ message: 'Access denied: no token' })
    }

    const secret = process.env.JWT_SECRET
    if (!secret) {
      return res
        .status(500)
        .json({ message: 'Server misconfigured: JWT_SECRET missing' })
    }

    const decoded = jwt.verify(token, secret, {
      clockTolerance: 5,
    })
    req.user = normalizeUser(decoded)

    if (!req.user.userId) {
      return res.status(401).json({ message: 'Invalid token: missing userId' })
    }
    return next()
  } catch (err) {
    const msg =
      err?.name === 'TokenExpiredError' ? 'Token expired' : 'Invalid token'
    return res.status(401).json({ message: msg })
  }
}

export default requireAuth
