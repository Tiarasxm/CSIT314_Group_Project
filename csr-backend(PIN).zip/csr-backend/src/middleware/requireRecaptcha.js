import { verifyRecaptcha } from '../../utils/verifyRecaptcha.js'

export async function requireRecaptcha(req, res, next) {
  const token = req.body?.recaptchaToken
  if (!token) return res.status(400).json({ error: 'reCAPTCHA token missing' })

  const ok = await verifyRecaptcha(token, req.ip)
  if (!ok)
    return res
      .status(400)
      .json({ error: 'reCAPTCHA failed. Please try again.' })

  next()
}
