// scripts/seed.js
import "dotenv/config";
import mongoose from "mongoose";
import { faker } from "@faker-js/faker";

import connectDB from "../config/db.js";
import User from "../models/User.js";
import Category from "../models/Category.js";
import Request from "../models/Request.js";

/* ---------------- helpers ---------------- */
const daysFromNow = (n) => {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d;
};

const makeReadableId = (prefix, n) => `${prefix}-${String(n).padStart(3, "0")}`;

/* ---------- configuration ---------- */
const COUNT_PIN = 70;
const COUNT_VOL = 30;


const CATEGORY_DEFS = [
  { name: "Elderly Care Visit", desc: "Friendly home visits and check-ins for seniors" },
  { name: "Grocery Assistance", desc: "Shopping and delivery of daily essentials" },
  { name: "Household Support", desc: "Light chores, tidying, and basic cleaning" },
  { name: "Medical Escort", desc: "Escort to clinic or hospital appointments" },
  { name: "Homework & Tutoring", desc: "Homework guidance for children and youths" },
];

const TOTAL_REQUESTS = 100;

/* ---------- helper: sensible request ---------- */
function makeSensibleRequest({ pin, volunteer, category, idx }) {
  const r = Math.random();
  let status, scheduledAt, needsVolunteer, title, details, note;

  const templates = {
    "Elderly Care Visit": {
      titles: [
        "Friendly afternoon visit",
        "Check-in and chat",
        "Reading session with senior",
        "Board games with elderly"
      ],
      details: [
        "30–45 mins conversation and wellbeing check.",
        "Bring board game or read newspapers together.",
        "Ensure medication reminders noted."
      ],
      note: "Please be patient and cheerful."
    },
    "Grocery Assistance": {
      titles: ["Weekly groceries run", "Fresh produce restock", "Essentials top-up"],
      details: [
        "Milk, eggs, bread, fruits, vegetables.",
        "Prefer low-sodium items; check expiry dates.",
        "Help carry items up to 3rd floor (no lift)."
      ],
      note: "Keep receipt for reimbursement."
    },
    "Household Support": {
      titles: ["Kitchen cleaning", "Light tidying & vacuum", "Window wipe-down"],
      details: [
        "Wipe counters, mop floor, clear sink.",
        "Vacuum carpets and dust shelves.",
        "Basic window cleaning (living room)."
      ],
      note: "Bring gloves if possible."
    },
    "Medical Escort": {
      titles: ["Clinic follow-up escort", "Polyclinic appointment support", "Hospital check-up escort"],
      details: [
        "Assist with registration and waiting queue.",
        "Appointment at 3:30 PM; escort to clinic.",
        "Wheelchair assistance if needed."
      ],
      note: "Confirm clinic queue number on arrival."
    },
    "Homework & Tutoring": {
      titles: ["Maths revision (Sec 2)", "Primary English reading", "Science homework help"],
      details: [
        "Focus on algebra and linear equations.",
        "Reading comprehension and vocabulary.",
        "Explain basics of energy and forces."
      ],
      note: "Keep session within 60 minutes."
    }
  };

  const tset = templates[category.name];

  // Distribute statuses sensibly
  if (r < 0.35) {
    // Pending — future, no volunteer
    status = "pending";
    scheduledAt = daysFromNow(faker.number.int({ min: 3, max: 14 }));
    needsVolunteer = false;
  } else if (r < 0.75) {
    // Upcoming — accepted/confirmed future, has volunteer
    status = Math.random() < 0.6 ? "accepted" : "confirmed";
    scheduledAt = daysFromNow(faker.number.int({ min: 1, max: 10 }));
    needsVolunteer = true;
  } else {
    // Past — completed only, past date
    status = "completed";
    scheduledAt = daysFromNow(-faker.number.int({ min: 2, max: 21 }));
    needsVolunteer = true;
  }

  title = faker.helpers.arrayElement(tset.titles);
  details = faker.helpers.arrayElement(tset.details);
  note = tset.note;

  return {
    title,
    details,
    status,
    scheduledAt,
    user: pin._id,
    volunteerId: needsVolunteer && volunteer ? volunteer._id : undefined,
    category: category._id,
    note,
  };
}

/* ------------------------- main seeder ------------------------- */
const run = async () => {
  try {
    await connectDB();
    console.log("✅ Connected to MongoDB");

    await Promise.all([User.deleteMany({}), Category.deleteMany({}), Request.deleteMany({})]);
    console.log("🧹 Cleared collections: users, categories, requests");

    // ---------- USERS ----------
    const users = [];

    for (let i = 1; i <= COUNT_PIN; i++) {
      users.push({
        userId: makeReadableId("pin", i),
        name: faker.person.fullName(),
        email: `pin${String(i).padStart(3, "0")}@csr.local`,
        role: "pin",
      });
    }
    for (let i = 1; i <= COUNT_VOL; i++) {
      users.push({
        userId: makeReadableId("vol", i),
        name: faker.person.fullName(),
        email: `vol${String(i).padStart(3, "0")}@csr.local`,
        role: "volunteer",
      });
    }

    const insertedUsers = await User.insertMany(users, { ordered: false });
    console.log(`👥 Seeded users: ${insertedUsers.length}`);

    const pins = insertedUsers.filter((u) => u.role === "pin");
    const volunteers = insertedUsers.filter((u) => u.role === "volunteer");

    // ---------- CATEGORIES ----------
    const categories = await Category.insertMany(
      CATEGORY_DEFS.map((c) => ({ name: c.name, description: c.desc }))
    );
    console.log(`🏷  Seeded categories: ${categories.length}`);

    // ---------- REQUESTS ----------
    const reqDocs = [];
    for (let i = 0; i < TOTAL_REQUESTS; i++) {
      const pin = pins[faker.number.int({ min: 0, max: pins.length - 1 })];
      const volunteer =
        volunteers.length > 0
          ? volunteers[faker.number.int({ min: 0, max: volunteers.length - 1 })]
          : null;
      const category = categories[i % categories.length];
      reqDocs.push(makeSensibleRequest({ pin, volunteer, category, idx: i + 1 }));
    }

    const insertedReqs = await Request.insertMany(reqDocs, { ordered: false });
    console.log(`📝 Seeded ${insertedReqs.length} requests across ${categories.length} categories`);

    // ---------- DONE ----------
    const firstPin = pins[0];
    console.log("\n👤 Example PIN for dashboard test:");
    console.log(`   Name: ${firstPin.name}`);
    console.log(`   userId: ${firstPin.userId}`);
    console.log(
      `➡️  Dashboard URL: http://localhost:${process.env.PORT || 5001}/api/pin/dashboard?userId=${firstPin.userId}`
    );

    console.log("\n🎉 All data seeded successfully!");
  } catch (err) {
    console.error("❌ Seeder error:", err);
    process.exit(1);
  } finally {
    await mongoose.connection.close().catch(() => {});
  }
};

run();
