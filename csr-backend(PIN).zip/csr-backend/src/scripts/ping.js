// scripts/ping.js
import "dotenv/config";
import mongoose from "mongoose";
import connectDB from "../config/db.js";

try {
  await connectDB();
  const admin = mongoose.connection.db.admin();
  const result = await admin.command({ ping: 1 });
  console.log("Atlas ping:", result);
  await mongoose.connection.close();
  process.exit(0);
} catch (e) {
  console.error("Ping failed:", e.message);
  process.exit(1);
}
