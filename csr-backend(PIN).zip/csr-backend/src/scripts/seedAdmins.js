import "dotenv/config";
import mongoose from "mongoose";
import connectDB from "../config/db.js";
import Admin from "../models/Admin.js";

async function main() {
  await connectDB();

  if (process.env.SEED_ADMINS !== "1") {
    console.error("❌ Refusing to run — set SEED_ADMINS=1 to seed admins/managers.");
    process.exit(1);
  }

  const accounts = [
    { adminId: "admin-001", name: "System Admin 1", email: "admin1@csr.local", password: "Admin123!", role: "admin" },
    { adminId: "admin-002", name: "System Admin 2", email: "admin2@csr.local", password: "Admin123!", role: "admin" },
    { adminId: "admin-003", name: "System Admin 3", email: "admin3@csr.local", password: "Admin123!", role: "admin" },
    { adminId: "admin-004", name: "System Admin 4", email: "admin4@csr.local", password: "Admin123!", role: "admin" },
    { adminId: "admin-005", name: "System Admin 5", email: "admin5@csr.local", password: "Admin123!", role: "admin" },
    { adminId: "manager-001", name: "Platform Manager 1", email: "manager1@csr.local", password: "Manager123!", role: "manager" },
    { adminId: "manager-002", name: "Platform Manager 2", email: "manager2@csr.local", password: "Manager123!", role: "manager" },
    { adminId: "manager-003", name: "Platform Manager 3", email: "manager3@csr.local", password: "Manager123!", role: "manager" },
  ];

  let created = 0;
  let skipped = 0;

  for (const acc of accounts) {
    const exists = await Admin.findOne({ email: acc.email }).lean();
    if (exists) {
      console.log(`⚠️  Skipped: ${acc.email} already exists`);
      skipped++;
      continue;
    }

    await Admin.create({
      adminId: acc.adminId,
      name: acc.name,
      email: acc.email,
      password: acc.password, // plain text password saved
      role: acc.role,
      status: "active",
    });

    console.log(`✅ Created: ${acc.role} (${acc.email})`);
    created++;
  }

  console.log(`🌱 Admin/Manager seeding complete. Created: ${created}, Skipped: ${skipped}.`);
  await mongoose.connection.close();
}

main().catch(async (err) => {
  console.error("❌ Seeding failed:", err);
  try {
    await mongoose.connection.close();
  } catch {}
  process.exit(1);
});
