import mongoose from 'mongoose'

export async function connectDB() {
  const uri = process.env.MONGO_URI

  if (!uri) throw new Error('MONGO_URI not found in .env')

  mongoose.set('strictQuery', true)

  // avoid duplicate connect attempts in dev
  if (mongoose.connection.readyState === 1) return mongoose.connection

  await mongoose.connect(uri, { serverSelectionTimeoutMS: 10000 })
  console.log('✅ MongoDB connected')
  return mongoose.connection
}

export default connectDB
