import Counter from '../models/Counter.js'
import User from '../models/User.js'

/** Read max userId like pin-062 and set counter.seq to 62 (if higher) */
export default async function syncPinCounter() {
  // Find max numeric suffix from userId (pin-###)
  const pins = await User.aggregate([
    { $match: { role: 'pin', userId: /^pin-\d+$/ } },
    {
      $project: {
        num: {
          $toInt: { $arrayElemAt: [{ $split: ['$userId', '-'] }, 1] },
        },
      },
    },
    { $group: { _id: null, maxNum: { $max: '$num' } } },
  ])

  const maxNum = pins?.[0]?.maxNum ?? 0

  // Upsert the counter and bump it forward if needed
  const doc = await Counter.findOneAndUpdate(
    { key: 'pinUser' },
    { $max: { seq: maxNum } }, // keep the higher of (existing seq, maxNum)
    { upsert: true, new: true }
  )

  // If counter.seq < maxNum, set it to maxNum exactly
  if (doc.seq < maxNum) {
    await Counter.updateOne({ key: 'pinUser' }, { $set: { seq: maxNum } })
  }
}
