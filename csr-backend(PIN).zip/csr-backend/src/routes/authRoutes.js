import express from 'express'
import {
  registerPinUser,
  loginPinUser,
  requestReset,
  resetPassword,
} from '../controllers/authController.js'

const router = express.Router()

router.post('/register', registerPinUser)
router.post('/login', loginPinUser)
router.post('/forgot-password', requestReset)
router.post('/reset-password', resetPassword)

export default router
