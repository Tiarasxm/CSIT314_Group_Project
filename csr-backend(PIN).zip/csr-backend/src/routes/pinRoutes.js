import express from 'express'
import requireAuth from '../middleware/requireAuth.js'
import {
  getPinProfile,
  updatePinProfile,
  changePinPassword,
} from '../controllers/pinProfileController.js'
import { getPinDashboard } from '../controllers/pinDashboardController.js'

const router = express.Router()

// AUTHED
router.get('/:userId/profile', requireAuth, getPinProfile)
router.put('/:userId/profile', requireAuth, updatePinProfile)
router.patch('/:userId/password', requireAuth, changePinPassword)

router.get('/dashboard', requireAuth, getPinDashboard)

export default router
