import { Router } from 'express'
import * as RequestController from '../controllers/requestController.js'
import requireAuth from '../middleware/requireAuth.js'

const router = Router()

router.use(requireAuth)

router.post('/', RequestController.createRequest)
router.get('/', RequestController.listRequests)
router.get('/:id', RequestController.getRequest)
router.patch('/:id', RequestController.updateRequest)
router.delete('/:id', RequestController.deleteRequest)
router.patch('/:id/accept', RequestController.acceptRequest)

export default router
