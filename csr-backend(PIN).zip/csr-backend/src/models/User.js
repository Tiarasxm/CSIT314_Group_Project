import mongoose from 'mongoose'
import bcrypt from 'bcrypt'

const UserSchema = new mongoose.Schema(
  {
    userId: { type: String, unique: true, index: true }, // e.g. pin-001

    role: {
      type: String,
      enum: ['pin', 'admin', 'volunteer', 'manager'],
      required: true,
    },

    status: {
      type: String,
      enum: ['active', 'inactive', 'suspended'],
      default: 'active',
      index: true,
    },

    // Auth / identity
    provider: {
      type: String,
      enum: ['local', 'google'],
      default: 'local',
      index: true,
    },

    firstName: { type: String, default: '' },
    lastName: { type: String, default: '' },
    name: { type: String, default: '' },

    email: { type: String, unique: true, sparse: true, index: true },

    phone: { type: String, default: '' },
    dob: { type: Date },
    gender: { type: String, default: 'Prefer not to say' },
    language: { type: String, default: '' },
    address: { type: String, default: '' },
    medicalNotes: { type: String, default: '' },
    avatarUrl: { type: String, default: '' },

    // Password & reset
    passwordHash: { type: String, select: false },

    resetPasswordTokenHash: { type: String, select: false, index: true },
    resetPasswordExpires: { type: Date, index: true },

    // For invalidating old JWTs after password change
    passwordChangedAt: { type: Date },
    tokenVersion: { type: Number, default: 0 },

    lastLoginAt: { type: Date },
  },
  { timestamps: true }
)

/* -------------------- Virtuals -------------------- */
UserSchema.virtual('fullName').get(function () {
  return this.name || `${this.firstName ?? ''} ${this.lastName ?? ''}`.trim()
})

/* -------------------- Instance Methods -------------------- */
UserSchema.methods.setPassword = async function (plain) {
  this.passwordHash = await bcrypt.hash(plain, 12)
  this.passwordChangedAt = new Date()
  // Optional: bump tokenVersion to invalidate existing JWTs immediately
  this.tokenVersion = (this.tokenVersion || 0) + 1
}

UserSchema.methods.checkPassword = async function (plain) {
  // passwordHash is select:false, ensure caller queried with .select('+passwordHash')
  if (!this.passwordHash) return false
  return bcrypt.compare(plain, this.passwordHash)
}

/* -------------------- Indexes (optional helpers) -------------------- */
// Speeds up auth & listings
UserSchema.index({ email: 1, provider: 1 })
UserSchema.index({ role: 1, status: 1 })

export default mongoose.model('User', UserSchema)
