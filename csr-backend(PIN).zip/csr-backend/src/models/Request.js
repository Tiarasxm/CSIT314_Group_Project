import mongoose from 'mongoose'

const { Schema } = mongoose

const RequestSchema = new Schema(
  {
    // Which PIN user created/owns this request (e.g. "pin-076")
    user: {
      type: String,
      required: true,
      index: true,
    },

    // Optional category (shown in listRequests/createRequest)
    category: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      index: true,
    },

    // Display / content fields
    title: { type: String, default: '' },
    details: { type: String, default: '' },
    location: { type: String, default: '' },

    // Datetimes
    preferredAt: { type: Date },
    scheduledAt: { type: Date },

    // Volunteer assignment (optional; used by acceptRequest etc.)
    volunteerId: { type: String }, // e.g. "pin-123" or "vol-001"
    volunteerName: { type: String },

    // Other optional display fields you previously had
    csrRepName: { type: String },
    mobile: { type: String },
    notes: { type: String }, // aka additionalNotes

    // Status lifecycle
    // controllers commonly use: pending, upcoming, completed
    // Some routes also set: accepted/confirmed/cancelled; keep them in enum for flexibility.
    status: {
      type: String,
      enum: [
        'pending',
        'upcoming',
        'accepted',
        'confirmed',
        'completed',
        'cancelled',
      ],
      default: 'pending',
      index: true,
    },
  },
  { timestamps: true }
)

// Text index for search in listRequests (?q=)
RequestSchema.index({
  title: 'text',
  details: 'text',
  location: 'text',
  notes: 'text',
  volunteerName: 'text',
  csrRepName: 'text',
  mobile: 'text',
})

// Helpful compound indexes for dashboards/lists
RequestSchema.index({ user: 1, status: 1, createdAt: -1 })
RequestSchema.index({ category: 1, createdAt: -1 })

export default mongoose.model('Request', RequestSchema)
