import mongoose from 'mongoose'
import Category from '../models/Category.js'

export const listCategories = async (_req, res) => {
  try {
    const items = await Category.find().sort({ name: 1 }).lean()
    res.json(items)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

export const getCategory = async (req, res) => {
  try {
    const { id } = req.params
    if (!mongoose.isValidObjectId(id))
      return res.status(400).json({ error: 'Invalid id' })
    const doc = await Category.findById(id).lean()
    if (!doc) return res.status(404).json({ error: 'Category not found' })
    res.json(doc)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

export const createCategory = async (req, res) => {
  try {
    const { name, description } = req.body
    if (!name) return res.status(400).json({ error: 'name required' })
    const exists = await Category.findOne({ name })
    if (exists)
      return res.status(409).json({ error: 'Category already exists' })
    const doc = await Category.create({ name, description })
    res.status(201).json(doc)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

export const updateCategory = async (req, res) => {
  try {
    const { id } = req.params
    if (!mongoose.isValidObjectId(id))
      return res.status(400).json({ error: 'Invalid id' })
    const doc = await Category.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    }).lean()
    if (!doc) return res.status(404).json({ error: 'Category not found' })
    res.json(doc)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

export const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params
    if (!mongoose.isValidObjectId(id))
      return res.status(400).json({ error: 'Invalid id' })
    const out = await Category.findByIdAndDelete(id).lean()
    if (!out) return res.status(404).json({ error: 'Category not found' })
    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

export default {
  listCategories,
  getCategory,
  createCategory,
  updateCategory,
  deleteCategory,
}
