import bcrypt from 'bcrypt'
import User from '../models/User.js'

/* ---------------------------------------------------------
   GET /api/pin/:userId/profile
   → Fetch personal profile for a PIN (person-in-need) user
--------------------------------------------------------- */
export async function getPinProfile(req, res) {
  try {
    const { userId } = req.params

    // Optional ownership enforcement
    if (req.user?.role === 'pin' && req.user?.userId !== userId) {
      return res.status(403).json({ message: 'Forbidden' })
    }

    const user = await User.findOne({ userId, role: 'pin' }).lean()
    if (!user) return res.status(404).json({ message: 'User not found' })

    const profile = {
      firstName: user.firstName || '',
      lastName: user.lastName || '',
      email: user.email || '',
      phone: user.phone || '',
      dob: user.dob ? new Date(user.dob).toISOString() : null,
      gender: user.gender || 'Prefer not to say',
      language: user.language || '',
      address: user.address || '',
      medicalNotes: user.medicalNotes || '',
      avatarUrl: user.avatarUrl || '',
    }

    res.json({ user: profile })
  } catch (e) {
    res.status(500).json({ message: e.message || 'Server error' })
  }
}

/* ---------------------------------------------------------
   PUT /api/pin/:userId/profile
   → Update personal profile for a PIN user
--------------------------------------------------------- */
export async function updatePinProfile(req, res) {
  try {
    const { userId } = req.params

    // Ensure only owner can modify their profile
    if (req.user?.role === 'pin' && req.user?.userId !== userId) {
      return res.status(403).json({ message: 'Forbidden' })
    }

    const {
      phone = '',
      gender = 'Prefer not to say',
      language = '',
      address = '',
      medicalNotes = '',
      avatarUrl = '',
      dob,
      firstName,
      lastName,
    } = req.body || {}

    const user = await User.findOne({ userId, role: 'pin' })
    if (!user) return res.status(404).json({ message: 'User not found' })

    // Update profile fields
    if (typeof firstName === 'string') user.firstName = firstName.trim()
    if (typeof lastName === 'string') user.lastName = lastName.trim()
    user.name = [user.firstName, user.lastName].filter(Boolean).join(' ')

    user.phone = typeof phone === 'string' ? phone.trim() : user.phone
    user.gender = gender
    user.language =
      typeof language === 'string' ? language.trim() : user.language
    user.address = typeof address === 'string' ? address.trim() : user.address
    user.medicalNotes =
      typeof medicalNotes === 'string' ? medicalNotes.trim() : user.medicalNotes
    user.avatarUrl =
      typeof avatarUrl === 'string' ? avatarUrl.trim() : user.avatarUrl

    // Date of birth update (optional clear)
    if (dob) {
      const parsed = new Date(dob)
      if (!isNaN(parsed.getTime())) user.dob = parsed
    } else if (dob === '') {
      user.dob = undefined // clear dob if empty string
    }

    await user.save()
    res.json({ ok: true, message: 'Profile updated', userId })
  } catch (e) {
    res.status(500).json({ message: e.message || 'Server error' })
  }
}

/* ---------------------------------------------------------
   PATCH /api/pin/:userId/password
   → Change PIN user password
--------------------------------------------------------- */
export async function changePinPassword(req, res) {
  try {
    const { userId } = req.params
    const { currentPassword, newPassword } = req.body || {}

    // Ensure ownership
    if (req.user?.role === 'pin' && req.user?.userId !== userId) {
      return res.status(403).json({ message: 'Forbidden' })
    }

    if (!currentPassword || !newPassword) {
      return res
        .status(400)
        .json({ message: 'Missing current or new password' })
    }
    if (newPassword.length < 8) {
      return res
        .status(400)
        .json({ message: 'New password must be at least 8 characters long' })
    }

    const user = await User.findOne({ userId, role: 'pin' }).select(
      '+passwordHash'
    )
    if (!user) return res.status(404).json({ message: 'User not found' })

    // Verify current password
    const valid = user.passwordHash
      ? await bcrypt.compare(currentPassword, user.passwordHash)
      : false
    if (!valid) {
      return res.status(400).json({ message: 'Current password is incorrect' })
    }

    // Hash new password and save
    user.passwordHash = await bcrypt.hash(newPassword, 10)
    await user.save()

    res.json({ ok: true, message: 'Password changed' })
  } catch (e) {
    res.status(500).json({ message: e.message || 'Server error' })
  }
}
