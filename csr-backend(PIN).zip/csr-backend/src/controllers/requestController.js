import mongoose from 'mongoose'
import Request from '../models/Request.js'

/* ---------------------------------------------------------
   Helper Functions
--------------------------------------------------------- */

/** Safely parse integer with fallback */
function toInt(v, d) {
  const n = parseInt(v, 10)
  return Number.isFinite(n) && n > 0 ? n : d
}

/** Escape regex special chars for safe text search */
function escapeRegExp(s = '') {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

/** Check if a string is a valid Mongo ObjectId */
const isOid = (v) => typeof v === 'string' && mongoose.isValidObjectId(v)

/* ---------------------------------------------------------
   Controller Functions
--------------------------------------------------------- */

/** List requests with filters, pagination, and search */
export const listRequests = async (req, res) => {
  try {
    const page = toInt(req.query.page, 1)
    const limit = Math.min(toInt(req.query.limit, 20), 200)
    const { status, group, q, category, from, to } = req.query

    const userParam =
      req.query.user ||
      req.query.userId ||
      req.query.volunteerId ||
      req.user?.userId ||
      req.user?.id ||
      null

    const filter = {}
    if (userParam) filter.user = userParam
    if (category && isOid(category)) filter.category = category

    // Group → status mapping
    const groupStatusMap = {
      pending: 'pending',
      upcoming: 'upcoming',
      past: 'completed',
    }
    if (groupStatusMap[group]) filter.status = groupStatusMap[group]
    else if (status) filter.status = status

    // Text search
    if (q?.trim()) {
      const rx = new RegExp(escapeRegExp(q.trim()), 'i')
      filter.$or = [{ title: rx }, { details: rx }, { location: rx }]
    }

    // Date range
    if (from || to) {
      filter.createdAt = {}
      if (from) filter.createdAt.$gte = new Date(from)
      if (to) filter.createdAt.$lte = new Date(to)
    }

    const [items, total] = await Promise.all([
      Request.find(filter)
        .populate({ path: 'category', select: 'name' })
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Request.countDocuments(filter),
    ])

    // Add categoryName shortcut for convenience
    const withCategoryName = items.map((r) => ({
      ...r,
      categoryName: r.category?.name ?? null,
    }))

    res.json({
      items: withCategoryName,
      total,
      page,
      pages: Math.ceil(total / limit),
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

/** Get a single request by ID */
export const getRequest = async (req, res) => {
  try {
    const { id } = req.params
    if (!mongoose.isValidObjectId(id))
      return res.status(400).json({ error: 'Invalid id' })

    const doc = await Request.findById(id)
      .populate({ path: 'category', select: 'name' })
      .lean()

    if (!doc) return res.status(404).json({ error: 'Request not found' })
    res.json({ ...doc, categoryName: doc.category?.name ?? null })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

/** Create a new request */
export const createRequest = async (req, res) => {
  try {
    const userId = req.user?.userId || req.body.user
    const description = (req.body.description ?? req.body.details ?? '').trim()
    const categoryId = req.body.categoryId || req.body.category
    const location = (req.body.location ?? '').trim()

    let preferredAt = req.body.preferredAt
      ? new Date(req.body.preferredAt)
      : null

    if (!preferredAt && req.body.preferredDate && req.body.preferredTime) {
      preferredAt = new Date(
        `${req.body.preferredDate}T${req.body.preferredTime}`
      )
    }

    // Validate required fields
    const missing = []
    if (!userId) missing.push('user')
    if (!categoryId) missing.push('categoryId')
    if (!description) missing.push('description')
    if (!location) missing.push('location')
    if (!preferredAt || isNaN(preferredAt.getTime()))
      missing.push('preferredDate+preferredTime')
    if (missing.length)
      return res
        .status(400)
        .json({ error: `Missing required fields: ${missing.join(', ')}` })

    if (!isOid(categoryId))
      return res.status(400).json({ error: 'Invalid categoryId' })

    const doc = await Request.create({
      title:
        req.body.title || `Request - ${new Date().toISOString().slice(0, 10)}`,
      details: description,
      category: categoryId,
      user: userId,
      preferredAt,
      location,
      status: 'pending',
    })

    const out = await Request.findById(doc._id)
      .populate({ path: 'category', select: 'name' })
      .lean()

    res.status(201).json({ ...out, categoryName: out.category?.name ?? null })
  } catch (err) {
    res.status(err?.name === 'ValidationError' ? 400 : 500).json({
      error:
        err?.name === 'ValidationError' ? 'Validation failed' : err.message,
    })
  }
}

/** Update a request by ID */
export const updateRequest = async (req, res) => {
  try {
    const { id } = req.params
    if (!mongoose.isValidObjectId(id))
      return res.status(400).json({ error: 'Invalid id' })

    // Normalize alias fields
    if (req.body.description) {
      req.body.details = req.body.description
      delete req.body.description
    }

    if (
      !req.body.preferredAt &&
      req.body.preferredDate &&
      req.body.preferredTime
    ) {
      req.body.preferredAt = new Date(
        `${req.body.preferredDate}T${req.body.preferredTime}`
      )
    }

    if (req.body.categoryId) {
      if (!isOid(req.body.categoryId))
        return res.status(400).json({ error: 'Invalid categoryId' })
      req.body.category = req.body.categoryId
      delete req.body.categoryId
    }

    const updated = await Request.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    })
      .populate({ path: 'category', select: 'name' })
      .lean()

    if (!updated) return res.status(404).json({ error: 'Request not found' })
    res.json({ ...updated, categoryName: updated.category?.name ?? null })
  } catch (err) {
    res.status(err?.name === 'ValidationError' ? 400 : 500).json({
      error:
        err?.name === 'ValidationError' ? 'Validation failed' : err.message,
    })
  }
}

/** Delete a request by ID */
export const deleteRequest = async (req, res) => {
  try {
    const { id } = req.params
    if (!mongoose.isValidObjectId(id))
      return res.status(400).json({ error: 'Invalid id' })

    const out = await Request.findByIdAndDelete(id).lean()
    if (!out) return res.status(404).json({ error: 'Request not found' })
    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

/** Accept a request (assign volunteer) */
export const acceptRequest = async (req, res) => {
  try {
    const { id } = req.params
    const { volunteerId } = req.body

    if (!mongoose.isValidObjectId(id))
      return res.status(400).json({ error: 'Invalid id' })
    if (!volunteerId)
      return res.status(400).json({ error: 'volunteerId is required' })

    const updated = await Request.findByIdAndUpdate(
      id,
      { status: 'accepted', volunteerId },
      { new: true, runValidators: true }
    )
      .populate({ path: 'category', select: 'name' })
      .lean()

    if (!updated) return res.status(404).json({ error: 'Request not found' })
    res.json({ ...updated, categoryName: updated.category?.name ?? null })
  } catch (err) {
    res.status(err?.name === 'ValidationError' ? 400 : 500).json({
      error:
        err?.name === 'ValidationError' ? 'Validation failed' : err.message,
    })
  }
}

/* ---------------------------------------------------------
   Export all handlers
--------------------------------------------------------- */
export default {
  listRequests,
  getRequest,
  createRequest,
  updateRequest,
  deleteRequest,
  acceptRequest,
}
