import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import crypto from 'crypto'

import User from '../models/User.js'
import Counter from '../models/Counter.js'
import { sendEmail } from '../utils/sendEmail.js'

/* ---------------------------------------------------------
   Helper Functions
--------------------------------------------------------- */

/** Return cookie options depending on environment */
function cookieOpts() {
  const prod = process.env.NODE_ENV === 'production'
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: prod,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  }
}

/** Sign a JWT token with 7-day expiry */
function signJWT(payload) {
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' })
}

/** Generate next sequential PIN user ID (e.g. pin-001) */
async function nextPinUserId() {
  const doc = await Counter.findOneAndUpdate(
    { key: 'pinUser' },
    { $inc: { seq: 1 } },
    { upsert: true, new: true }
  )
  return `pin-${String(doc.seq).padStart(3, '0')}`
}

/** Validation helpers */
const validEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v || ''))
const validPhone = (v) =>
  !v ? true : /^\+[1-9]\d{7,14}$/.test(String(v).replace(/\s+/g, ''))
const validPassword = (v) =>
  /^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(String(v || ''))

/** SHA256 helper */
const HASH = (s) => crypto.createHash('sha256').update(s).digest('hex')

/* ---------------------------------------------------------
   REGISTER (PUBLIC)
   POST /api/pin/register
--------------------------------------------------------- */
export async function registerPinUser(req, res) {
  try {
    let {
      firstName = '',
      lastName = '',
      email = '',
      password = '',
      phone = '',
    } = req.body || {}

    firstName = firstName.trim()
    lastName = lastName.trim()
    email = email.trim().toLowerCase()
    phone = phone.replace(/\s+/g, '')

    // Validation
    if (!firstName || !lastName)
      return res
        .status(400)
        .json({ ok: false, message: 'First and last name required' })
    if (!validEmail(email))
      return res
        .status(400)
        .json({ ok: false, message: 'Invalid email address' })
    if (!validPhone(phone))
      return res.status(400).json({
        ok: false,
        message: 'Phone must be in E.164 format, e.g. +6591234567',
      })
    if (!validPassword(password))
      return res.status(400).json({
        ok: false,
        message: 'Password must be ≥8 chars and include letters & numbers',
      })

    // Check duplicates
    const exists = await User.findOne({ email }).lean()
    if (exists)
      return res
        .status(409)
        .json({ ok: false, message: 'Email already in use' })

    const passwordHash = await bcrypt.hash(password, 10)

    // Allocate sequential userId (with retry for rare collision)
    for (let i = 0; i < 3; i++) {
      const userId = await nextPinUserId()
      try {
        const user = await User.create({
          userId,
          role: 'pin',
          firstName,
          lastName,
          name: `${firstName} ${lastName}`.trim(),
          email,
          phone,
          passwordHash,
        })

        const token = signJWT({
          userId: user.userId,
          role: user.role,
          email: user.email,
          name: user.name,
        })

        res.cookie('token', token, cookieOpts())

        return res.status(201).json({
          ok: true,
          message: 'Registered successfully',
          token,
          user: {
            userId: user.userId,
            role: user.role,
            firstName: user.firstName,
            lastName: user.lastName,
            name: user.name,
            email: user.email,
            phone: user.phone || '',
          },
        })
      } catch (err) {
        // Retry if userId collision
        if (err?.code === 11000 && err?.keyPattern?.userId) continue

        if (err?.code === 11000) {
          const key = Object.keys(err.keyPattern || {})[0] || 'field'
          return res
            .status(409)
            .json({ ok: false, message: `Duplicate ${key}` })
        }
        throw err
      }
    }

    return res
      .status(500)
      .json({ ok: false, message: 'Failed to allocate userId, please retry.' })
  } catch (err) {
    console.error('Register error:', err)
    return res
      .status(500)
      .json({ ok: false, message: err.message || 'Server error' })
  }
}

/* ---------------------------------------------------------
   LOGIN (PUBLIC)
   POST /api/pin/login
--------------------------------------------------------- */
export async function loginPinUser(req, res) {
  try {
    const email = String(req.body?.email || '')
      .trim()
      .toLowerCase()
    const password = String(req.body?.password || '')

    if (!validEmail(email) || !password)
      return res
        .status(400)
        .json({ ok: false, message: 'Invalid email or password' })

    const user = await User.findOne({ email, role: 'pin' }).select(
      '+passwordHash'
    )
    if (!user?.passwordHash)
      return res
        .status(400)
        .json({ ok: false, message: 'Invalid email or password' })

    const ok = await bcrypt.compare(password, user.passwordHash)
    if (!ok)
      return res
        .status(400)
        .json({ ok: false, message: 'Invalid email or password' })

    const name = user.name || `${user.firstName} ${user.lastName}`.trim()
    const token = signJWT({
      userId: user.userId,
      role: user.role,
      email: user.email,
      name,
    })

    res.cookie('token', token, cookieOpts())

    return res.json({
      ok: true,
      message: 'Logged in successfully',
      token,
      user: {
        userId: user.userId,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
        name,
        email: user.email,
        phone: user.phone || '',
      },
    })
  } catch (err) {
    console.error('Login error:', err)
    return res
      .status(500)
      .json({ ok: false, message: err.message || 'Server error' })
  }
}

/* ---------------------------------------------------------
   ME (AUTH)
   GET /api/auth/me
--------------------------------------------------------- */
export function me(req, res) {
  if (!req.user?.userId)
    return res.status(401).json({ ok: false, message: 'Unauthenticated' })

  const name =
    req.user.name ||
    [req.user.firstName, req.user.lastName].filter(Boolean).join(' ') ||
    'Friend'

  res.json({ ok: true, userId: req.user.userId, name })
}

/* ---------------------------------------------------------
   PASSWORD RESET FLOW
--------------------------------------------------------- */
export async function requestReset(req, res) {
  const { email } = req.body || {}
  const genericMsg = {
    ok: true,
    message: "If an account exists, you'll receive a reset link shortly.",
  }

  try {
    const user = await User.findOne({
      email: (email || '').toLowerCase().trim(),
    })
    if (!user || user.provider === 'google')
      return res.status(200).json(genericMsg)

    const token = crypto.randomBytes(32).toString('hex')
    user.resetPasswordTokenHash = HASH(token)
    user.resetPasswordExpires = new Date(Date.now() + 15 * 60 * 1000) // 15 min
    await user.save()

    const resetUrl = `${process.env.APP_URL}/reset-password?token=${token}`
    const html = `
      <p>Hello${user.firstName ? ' ' + user.firstName : ''},</p>
      <p>Click the button below to reset your password (expires in 15 min):</p>
      <p><a href="${resetUrl}" style="background:#CF8A2E;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;">Reset Password</a></p>
      <p>If you didn’t request this, ignore this email.</p>
    `
    await sendEmail({ to: user.email, subject: 'Reset your password', html })

    if (process.env.NODE_ENV !== 'production')
      console.log('DEV reset link:', resetUrl)
  } catch (err) {
    if (process.env.NODE_ENV !== 'production')
      console.error('Reset request error:', err)
  }

  return res.status(200).json(genericMsg)
}

export async function resetPassword(req, res) {
  try {
    const { token, password } = req.body || {}
    if (!token || !validPassword(password))
      return res.status(400).json({ ok: false, message: 'Invalid request' })

    const tokenHash = HASH(token)
    const user = await User.findOne({
      resetPasswordTokenHash: tokenHash,
      resetPasswordExpires: { $gt: new Date() },
    })

    if (!user)
      return res
        .status(400)
        .json({ ok: false, message: 'Link is invalid or has expired.' })

    user.passwordHash = await bcrypt.hash(password, 10)
    user.resetPasswordTokenHash = undefined
    user.resetPasswordExpires = undefined
    user.passwordChangedAt = new Date()
    user.tokenVersion = (user.tokenVersion || 0) + 1
    await user.save()

    return res.json({
      ok: true,
      message: 'Password has been reset. You can now log in.',
    })
  } catch (err) {
    console.error('Reset password error:', err)
    return res.status(500).json({ ok: false, message: 'Server error' })
  }
}

/* ---------------------------------------------------------
   LOGOUT (AUTH)
   POST /api/auth/logout
--------------------------------------------------------- */
export function logout(req, res) {
  res.clearCookie('token', cookieOpts())
  res.json({ ok: true, message: 'Logged out successfully' })
}

/* ---------------------------------------------------------
   EXPORT
--------------------------------------------------------- */
export default {
  registerPinUser,
  loginPinUser,
  me,
  requestReset,
  resetPassword,
  logout,
}
