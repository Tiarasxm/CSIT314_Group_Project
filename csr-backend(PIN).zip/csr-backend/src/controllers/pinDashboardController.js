import User from '../models/User.js'
import Request from '../models/Request.js'

/* ---------------------------------------------------------
   GET /api/pin/dashboard
   Description:
     Returns dashboard data for a Person-In-Need (PIN) user:
     - Greeting info
     - Counts for request groups
     - Preview list of upcoming requests

   Query Params:
     - user | userId     → explicit PIN ID (e.g. pin-072), defaults to JWT user
     - previewLimit      → number of upcoming preview cards (default 10, max 20)

   Groups:
     pending  → status: "pending"
     upcoming → status in ["upcoming", "accepted", "confirmed"]
     past     → status: "completed"
--------------------------------------------------------- */
export const getPinDashboard = async (req, res) => {
  try {
    /* ------------------- Resolve Current PIN ------------------- */
    const pinUserId =
      (req.query.user || req.query.userId || '').trim() ||
      req.user?.userId ||
      ''

    if (!pinUserId) {
      return res.status(400).json({
        message: 'Missing userId (pass ?user=pin-### or login required)',
      })
    }

    const pinDoc = await User.findOne({ userId: pinUserId, role: 'pin' })
      .select('userId name firstName lastName email')
      .lean()

    if (!pinDoc) return res.status(404).json({ message: 'User not found' })

    /* ------------------- Filters & Constants ------------------- */
    const UPCOMING_STATES = ['upcoming', 'accepted', 'confirmed']
    const PENDING_FILTER = { user: pinUserId, status: 'pending' }
    const UPCOMING_FILTER = {
      user: pinUserId,
      status: { $in: UPCOMING_STATES },
    }
    const PAST_FILTER = { user: pinUserId, status: 'completed' }

    // Limit preview cards for upcoming requests
    const previewLimit = Math.min(
      parseInt(req.query.previewLimit, 10) || 10,
      20
    )

    /* ------------------- Fetch Data in Parallel ------------------- */
    const [pendingCount, upcomingCount, pastCount, upcomingDocs] =
      await Promise.all([
        Request.countDocuments(PENDING_FILTER),
        Request.countDocuments(UPCOMING_FILTER),
        Request.countDocuments(PAST_FILTER),

        // Preview list for upcoming requests
        Request.find(UPCOMING_FILTER)
          .populate({ path: 'category', select: 'name' })
          .sort({
            scheduledAt: 1, // earliest upcoming first
            preferredAt: 1,
            createdAt: -1,
          })
          .limit(previewLimit)
          .select(
            'title details location preferredAt scheduledAt status createdAt volunteerName csrRepName mobile category'
          )
          .lean(),
      ])

    /* ------------------- Transform for UI ------------------- */
    const upcoming = upcomingDocs.map((r) => ({
      ...r,
      when: r.scheduledAt || r.preferredAt || null, // unified time field
      categoryName: r.category?.name ?? null, // flat category name
    }))

    const displayName =
      pinDoc.name ||
      [pinDoc.firstName, pinDoc.lastName].filter(Boolean).join(' ') ||
      'Friend'

    /* ------------------- Response ------------------- */
    return res.json({
      user: {
        userId: pinDoc.userId,
        name: displayName,
        email: pinDoc.email || '',
      },
      stats: {
        pending: pendingCount,
        upcoming: upcomingCount,
        past: pastCount,
      },
      upcoming,
    })
  } catch (err) {
    console.error('getPinDashboard error:', err)
    res.status(500).json({ message: err.message || 'Server error' })
  }
}

/* ---------------------------------------------------------
   Export Controller
--------------------------------------------------------- */
export default { getPinDashboard }
