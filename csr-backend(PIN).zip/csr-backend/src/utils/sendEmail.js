// utils/sendEmail.js
import nodemailer from "nodemailer";

export async function sendEmail({ to, subject, html }) {
  // Use your SMTP. For quick dev, use Ethereal:
  // const test = await nodemailer.createTestAccount();
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });

  const info = await transporter.sendMail({
    from: process.env.EMAIL_FROM || '"CSR Support" <no-reply@csrapp.local>',
    to, subject, html,
  });

  // Optional debug
  if (nodemailer.getTestMessageUrl) {
    console.log("Preview URL:", nodemailer.getTestMessageUrl(info));
  }
}
