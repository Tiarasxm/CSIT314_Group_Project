// utils/verifyRecaptcha.js
export async function verifyRecaptcha(token, remoteip) {
  try {
    const params = new URLSearchParams();
    params.append("secret", process.env.RECAPTCHA_SECRET);
    params.append("response", token);
    if (remoteip) params.append("remoteip", remoteip);

    const resp = await fetch("https://www.google.com/recaptcha/api/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
    });

    const data = await resp.json();
    // data: { success, challenge_ts, hostname, ... }
    return data.success === true;
  } catch {
    return false;
  }
}
